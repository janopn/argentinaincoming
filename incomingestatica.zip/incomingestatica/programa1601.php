<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
			<h2 class="font-weight-light text-white mb-2" id="titulo">Buenos Aires de Lujo</h2>
            <h5 class="font-weight-light text-white mb-1" id="noches">3 Noches</h5>
 
            <div class="mb-3">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline" />
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline" />
              <img src="iconos/excursion_b.svg" alt="Excursión" width="36px" class="m-0 d-inline" />
        <!--      <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline" />-->
            </div>                
 
 
 
            <ul class="text-white pl-3">
              <li>3 noches de alojamiento con desayuno en Hotel Hilton o similar (Cat. 5*)</li>
              <li>City Tour</li>
              <li>Cena Show de Tango</li>
            </ul>  
        
              
              
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
<!--
			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
-->			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/160101.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/160102.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/160103.jpg" alt="Image" class="img-fluid rounded" />
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>




    <div class="site-section">
      <div class="container">

        <form action="consultaprograma.php" class=" bg-light">

			
		  <div class="row bg-light">
			  			  	  			  
                <div class="col-12 col-md-9 mt-4 pl-3">
	    			<h3 class="font-weight-light azul">¡Reservá tu programa!</h3>
					<h6 class="mb-2" >Seleccioná la opción de tu preferencia y consultanos</h6>			
                </div>
                <!--
				<div class="col-12 col-md-3 mt-4  ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			    -->
   
		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  
          <!-- -->			  
		  <div class="row bg-light pb-3 mb-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha1">Septiembre a Diciembre</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel1">Hotel Hilton o similar (Cat. 5*)</label>
	        </div>		

		    <div class="col-lg-6 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(1, 'DBL');" checked></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1DBL">u$d 300</strong>
	    		  <strong class="text-primary legal d-block" id="base1">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		

          </div>
		  <!-- -->
        
        
        
        
        
		  <div class="row bg-light">		  
            <div class="col-12 mt-2 mb3">
				<strong class="text-primary legal d-block mb-3">No válidas para días festivos o feriados en Argentina.</strong>								
            </div>
		  </div>	
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="submit" value="Continuar" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        
		  
          
        </form>
          
          
      </div>
    </div>    
	

	  
	  
<!--		
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
 
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 1</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio <a href="experiencia.php" class=" d-inline subrayado">City Tour Panorámico</a> illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur <a href="experiencia.php" class="d-inline subrayado">Paseo en bici</a> adipisicing elit.</p>
                                
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 2</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus <a href="experiencia.php" class=" d-inline subrayado">Visita a bodega Zucardi</a> alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>
            
            <hr />

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 3</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>

              </div>                
            </div>

            
            <hr />

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 4</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>


          </div>
          
          
          
        </div>
      </div>
    </div>    
-->		
		
		
		
		
		
		
		
		
		
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios"  />
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
  <?php include 'scriptsprogramas.html';?>

 

    
  </body>
</html>