<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   




 
    <div class="site-section bg-light">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS DE 4 A 6 NOCHES</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/iguazu2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Cataratas del Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 590</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/bariloche2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Bariloche</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 790</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/iguazu2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Cataratas del Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 590</strong>
              </div>
            </a>
          </div>



        </div>
      
      </div>
      
    
    </div>
    
 
 
 
 
  
   
    



    
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-5 font-weight-light text-black">¿QUERÉS VIAJAR CON NOSOTROS?</h2>
            <p class="mb-0"><a href="contacto.php" class="btn btn-primary py-3 px-5 text-white rounded">¡Consultanos!</a></p>
          </div>
        </div>
      </div>
    </div>    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>