<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">City Tour Panorámico</h2>
            <h5 class="font-weight-light text-white mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
  
  
            <div class="mb-3">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/barco_b.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
              <img src="iconos/bici_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/comida_b.svg" alt="Comida" width="36px" class="m-0 d-inline">
            </div>                
  
  
 
            <ul class="text-white pl-3 mb-4">
              <li>Bus turistico</li>
              <li>4 descensos</li>
              <li>Almuerzo (sin bebidas)</li>
            </ul>  
 
            
            <p class="font-weight-light text-white mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
            <p class="font-weight-light text-white mb-0"><strong>Duración:</strong> 8 hs.</p>            
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
 
			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  



          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slidercaminito.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/slidermapa.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>


	  
	  
    <div class="site-section">
      <div class="container">

        <form action="reservaexp.php">

			
		  <div class="row bg-light">
			  			  
            <div class="col-lg-3 border-right mt-4 pt-4 pl-4">
			
              <!--<strong class="text-primary legal d-block">DESDE</strong>-->
              <strong class="text-primary preciodestacado d-block mb-1">u$d 190</strong>
              <strong class="text-primary legal d-block ">Tarifa final por pasajero</strong>
			
			</div>
			  
			  
            <div class="col-lg-9 ">
			
    		  <div class="row bg-light ">
			  			  
                <div class="col-md-12 mt-4 ml-2">
	    			<h3 class="font-weight-light azul">¡Reservá tu experiencia!</h3>
					<h6 class="mb-2" >En 2 simples pasos y sin tarjeta de crédito</h6>			
                </div>
    		  </div>	  			 
			  
			
    		  <div class="row bg-light ">			  
                <div class="col-12 col-lg-9 mt-3 px-4">
    	  	      <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">Paso 1 de 2</div>
                  </div>				
    			</div>

				<div class="col-12 col-lg-3 mt-1 px-4 ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho">
    			</div> 		 
			  
    		  </div>	
			</div>

		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr>								
            </div>
		  </div>	
			
			  
			  
		  <div class="row bg-light pb-3">		  			  
          <div class="col-lg-4 col-12 pad border-right">
                                                
                <label class="mb-1 h6 azul"  for="fecha">Fecha</label>
                <input type="text" name="fecha" class="form-control datepicker px-2 mb-4" placeholder="Fecha">
			  
		  </div>	  
			  

		  <div class="col-lg-8 col-12 pad">
			  
            <h6 class="mb-3 azul mt-1" >Pasajeros</h6>             
			  
            <div class="mb-0">
			  <div class="row mb-0">	
                <div class="col-5 mb-0">
                  <label class="text-black m-0" for="adultos1">Adultos: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="adultos1" name="adultos1" min="1" max="20" value="2">
    			</div>	  
                <div class="col-7 mb-0">				  
				  <label class="text-black m-0" for="menores1">Menores: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="menores1" name="menores1" min="0" max="20" value="0">
				  <p class="legal m-0 ">(2 a 11 años inclusive)</p>  
    		    </div>
			  </div>
            </div>
			  

            <div>
              <label class="text-black" for="infante1">Viajo con bebé/s: </label>
              <input type="checkbox"  id="infante1" class="d-inline mr-2">
            </div>
			
			  
			  
			  
	      </div>		
			  
			  
			  
	
                   
          
          
          
 
          </div>
          
        </form>
          
          
      </div>
    </div>  
	  

	  	  
	  
	  
	  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
 
            <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
            </p>
            
          </div>
         
        </div>
      </div>
    </div>    
	  
	  
	  
	  
	  
	  
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>