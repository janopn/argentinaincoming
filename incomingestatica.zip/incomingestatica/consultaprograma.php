<!DOCTYPE html>
<html lang="en">
<?php include 'head.html'; ?>
  <body>
  <div class="site-wrap">
    <?php include 'menu.html'; ?>
    <?php include 'incompleteMandatoryFields.html'; ?>
    <div class="site-section bg-white">
      <div class="container">
        <form class="bg-light" action="thanks.php" method="post" name="Form" onsubmit="return processForm();">
          <div class="row bg-light">
            <div class="col-12 col-md-9 mt-4 pl-3">
              <h3 class="font-weight-light azul">¡Envía tu consulta!</h3>
              <h6 class="mb-2">Completá tus datos y consultanos</h6>
            </div>
          </div>
          <div class="row bg-light">
            <div class="col-12 mt-2">
              <hr />
            </div>
          </div>	
          <div class="row bg-light">
            <div class="col-12 mt-2">
              <h2 class="font-weight-light mb-2" id="titulo">titulo</h2>
            </div>
          </div>
          <div class="row bg-light">
            <div class="col-lg-3 col-md-12">
              <label class="mb-1 h6 azul" id="rangofecha">fecha</label>
            </div>
            <div class="col-lg-2 col-md-12">
              <h5 class=" mb-1" id="noches">noches</h5>
            </div>
            <div class="col-lg-4 col-md-12">
              <label class="mb-1 h6" id="hotel">hotel</label>
            </div>
            <div class="col-lg-3 col-md-12">
              <strong class="text-primary preciodestacado d-block mb-1" id="precio">precio</strong>
              <strong class="text-primary legal d-block" id="base">base</strong>
            </div>
          </div>
          <div class="row bg-light">
            <div class="col-12 mt-2">
              <hr />
          </div>
        </div>
          <div class="row form-group bg-light">
            <div class="col-md-6 mb-3 mb-md-0">
              <label class="text-black" for="fname">Nombre</label>
              <input name="fname" type="text" id="fname" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="text-black" for="lname">Apellido</label>
              <input name="lname" type="text" id="lname" class="form-control">
            </div>
          </div>
          <div class="row form-group bg-light">
            <div class="col-md-3 mb-3 mb-md-0">
              <label class="text-black" for="fechad">Fecha</label> 
              <input type="text" name="fechad" class="form-control datepicker px-2" placeholder="" />
            </div>
            <div class="col-md-3 mb-3 mb-md-0">
              <label class="text-black" for="cant">Cantidad de pasajeros</label> 
              <input name="cant" type="cant" id="cant" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="text-black" for="ltel">Teléfono</label>
              <input name="ltel" type="text" id="ltel" class="form-control">
            </div>
          </div>
          <div class="row form-group bg-light">
            <div class="col-md-12">
              <label class="text-black" for="email">E-Mail</label> 
              <input name="email" type="email" id="email" class="form-control">
            </div>
          </div>
          <div class="row form-group bg-light">
            <div class="col-md-12">
              <label class="text-black" for="message">Mensaje</label> 
              <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="¿Que te gustaría consultarnos?"></textarea>
            </div>
          </div>
          <div class="row form-group bg-light">
            <div class="col-md-12">
              <div class="g-recaptcha-outer">
                <div class="g-recaptcha-inner">
                  <div class="g-recaptcha" data-sitekey="6LcXqZEgAAAAADRZaOX7dYjZ2HSFwMJq_ZU6iNuV"></div>
                </div>
              </div>
            </div>
          </div>
          <input type="hidden" id="hdntitulo" name="hdntitulo" value="">
          <input type="hidden" id="hdnnoches" name="hdnnoches" value="">
          <input type="hidden" id="hdnrangofecha" name="hdnrangofecha" value="">
          <input type="hidden" id="hdnhotel" name="hdnhotel" value="">
          <input type="hidden" id="hdnprecio" name="hdnprecio" value="">
          <input type="hidden" id="hdnbase" name="hdnbase" value="">
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="hidden" id="hdnsource" name="hdnsource" value="consultaprograma">
              <input type="submit" value="Enviar consulta" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        </form>
      </div>
    </div>
    <?php include 'footer.html'; ?>
  </div>
  <?php include 'scripts.html'; ?>
  </body>
  <script src="validate.js"></script>
  <script type="text/javascript">
    document.getElementById('titulo').innerHTML = sessionStorage.getItem('titulo');
    document.getElementById('noches').innerHTML = sessionStorage.getItem('noches');
    document.getElementById('rangofecha').innerHTML = sessionStorage.getItem('rangofecha');
    document.getElementById('hotel').innerHTML = sessionStorage.getItem('hotel');
    document.getElementById('precio').innerHTML = sessionStorage.getItem('precio');
    document.getElementById('base').innerHTML = sessionStorage.getItem('base');

  function processForm() {
    fnameValidation = validateField("fname");
    emailValidation = validateField("email");
    recaptchaValidation = grecaptcha.getResponse() != "";

    document.getElementById('hdntitulo').value = sessionStorage.getItem('titulo');
    document.getElementById('hdnnoches').value = sessionStorage.getItem('noches');
    document.getElementById('hdnrangofecha').value = sessionStorage.getItem('rangofecha');
    document.getElementById('hdnhotel').value = sessionStorage.getItem('hotel');
    document.getElementById('hdnprecio').value = sessionStorage.getItem('precio');
    document.getElementById('hdnbase').value = sessionStorage.getItem('base');

    isValid = fnameValidation && emailValidation && recaptchaValidation;

    if(!isValid){
      $('#myModal').modal();
    }

    return isValid;
  }
  </script>
</html>