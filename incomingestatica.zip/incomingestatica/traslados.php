<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   
      

    <div class="slide-one-item home-slider owl-carousel">
      
        
      <div class="site-blocks-cover " style="background-image: url(images/slidertraslados.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-9  transparente rounded pt-4" >
              <h2 class="text-white font-weight-normal ">TRASLADOS PRIVADOS EN BUENOS AIRES</h2>
              <p class="mb-4 text-white">Servicio de traslados privados de Arribos y Partidas en los Aeropuertos de Buenos Aires. Te estaremos esperando para conducirte a tu hotel con seguridad y profesionalismo.</p>
                <!--
              <p class=""><a href="contacto.php" class="btn btn-primary py-2 px-3 text-white rounded">¡Pedinos cotización!</a></p>  -->
            </div>
          </div>
        </div>
      </div>  
        
        
    </div>
      
      

      
    <div class="site-section" id="seccionadicionales">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4 azul">Traslado desde Aeropuerto de Ezeiza a Hoteles en Buenos Aires</h3>
            <strong>SOLO IDA O VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 35</strong></p>
            <strong>IDA Y VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 70</strong></p>         
          </div>
   
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4 azul">Traslado desde Aeroparque Jorge Newbery a Hoteles en Buenos Aires</h3>
            <strong>SOLO IDA O VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 20</strong></p>
            <strong>IDA Y VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 40</strong></p>         
          </div>
                        
          <div class="col-md-12 mb-4">
            <p class=""><a href="contacto.php" class="btn btn-primary py-2 px-3 text-white rounded">Reservas y consultas</a></p> 
          </div>
              
            
        </div>
      </div>
    </div>    
      
    
  
  
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios" />
          </div>
         </div>
      </div>
    </div>
   
   
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
    
  </body>
</html>