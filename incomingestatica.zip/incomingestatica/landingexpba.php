<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   







  
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12 pl-lg-5">
            <h2 class="font-weight-light text-white mb-4">Buenos Aires</h2>
            <p class="text-white">La Ciudad de Buenos Aires se destaca por tener una vida cultural muy activa. Cines, teatros, museos, bibliotecas, paseos y centros culturales conforman una oferta variada de cultura y entretenimiento. Se destacan los centros culturales Recoleta y General San Martín, el planetario Galileo Galilei, los museos de Arte Moderno y de Arte Latinoamericano (MALBA), los barrios de La Boca y San Telmo, el cementerio de La Recoleta, el Rosedal de Palermo, el Teatro Colón, Plaza de Mayo y Plaza del Congreso, entre otros.</p>
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/16_1.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/16_2.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/16_3.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>

   



    <div class="site-section ">
      
        
      <div class="container">  
        
        
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">EXPERIENCIAS EN BUENOS AIRES</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1601.php" class="unit-2  rounded text-center">
              <img src="images/e160101.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Scooting BA - Recoleta & Palermo</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 40</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1602.php" class="unit-2  rounded text-center">
              <img src="images/e160201.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Buenos Aires al Sur</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">Tarifa TOTAL del tour (hasta 5 pasajeros)</strong>
                  <strong class=" m-0 d-block precio">u$d 200</strong>
              </div>
            </a>
          </div>

            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1603.php" class="unit-2  rounded text-center">
              <img src="images/e160301.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Buenos Aires al Norte</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">Tarifa TOTAL del tour (hasta 5 pasajeros)</strong>
                  <strong class=" m-0 d-block precio">u$d 200</strong>
              </div>
            </a>
          </div>
    
            
   
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1604.php" class="unit-2  rounded text-center">
              <img src="images/e160401.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Bodega Gamboa</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/vino_n.svg" alt="Degustacion" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />   
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 120</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1605.php" class="unit-2  rounded text-center">
              <img src="images/e160402.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Bodega Gamboa + paseo en Mehari</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/vino_n.svg" alt="Degustacion" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />   
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 170</strong>
              </div>
            </a>
          </div>
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1606.php" class="unit-2  rounded text-center">
              <img src="images/e160601.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Inolvidable Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">Tarifa TOTAL del tour (hasta 5 pasajeros)</strong>
                  <strong class=" m-0 d-block precio">u$d 400</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1607.php" class="unit-2  rounded text-center">
              <img src="images/e160701.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Postales de Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/barco_n.svg" alt="Navegacion" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 10</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1608.php" class="unit-2  rounded text-center">
              <img src="images/e160801.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Delta Tigre Full Day</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/barco_n.svg" alt="Navegacion" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 150</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1609.php" class="unit-2  rounded text-center">
              <img src="images/e160901.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Avenida Corrientes y las costumbres porteñas</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 45</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1610.php" class="unit-2  rounded text-center">
              <img src="images/e161001.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Estadios Tour</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 60</strong>
              </div>
            </a>
          </div>
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1611.php" class="unit-2  rounded text-center">
              <img src="images/e161101.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Día de campo en Estancia La Candelaria</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 90</strong>
              </div>
            </a>
          </div>
  
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1612.php" class="unit-2  rounded text-center">
              <img src="images/e161201.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Arte urbano - Circuito Palermo</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 20</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1613.php" class="unit-2  rounded text-center">
              <img src="images/e161301.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Arte urbano - Circuito San Telmo</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 20</strong>
              </div>
            </a>
          </div>
   
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1614.php" class="unit-2  rounded text-center">
              <img src="images/e161401.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Arte urbano - Circuito La Boca</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 20</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1615.php" class="unit-2  rounded text-center">
              <img src="images/e161501.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Tango y fileteado porteño</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/museo_n.svg" alt="Museo" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 55</strong>
              </div>
            </a>
          </div>
            
            
            
        </div>
        
              
      </div>        
        
    
    </div>  
      
      
      
      
    <div class="slide-one-item home-slider owl-carousel">
      
        
      <div class="site-blocks-cover " style="background-image: url(images/slidertraslados.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-9  transparente rounded pt-4" >
              <h2 class="text-white font-weight-normal ">TRASLADOS PRIVADOS EN BUENOS AIRES</h2>
              <p class="mb-4 text-white">Servicio de traslados privados de Arribos y Partidas en los Aeropuertos de Buenos Aires. Te estaremos esperando para conducirte a tu hotel con seguridad y profesionalismo.</p>
                <!--
              <p class=""><a href="contacto.php" class="btn btn-primary py-2 px-3 text-white rounded">¡Pedinos cotización!</a></p>  -->
            </div>
          </div>
        </div>
      </div>  
        
        
    </div>
      
      

      
    <div class="site-section" id="seccionadicionales">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4 azul">Traslado desde Aeropuerto de Ezeiza a Hoteles en Buenos Aires</h3>
            <strong>SOLO IDA O VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 35</strong></p>
            <strong>IDA Y VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 70</strong></p>         
          </div>
   
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4 azul">Traslado desde Aeroparque Jorge Newbery a Hoteles en Buenos Aires</h3>
            <strong>SOLO IDA O VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 20</strong></p>
            <strong>IDA Y VUELTA</strong>
            <p>Precio del traslado hasta 5 pasajeros: <strong>USD 40</strong></p>         
          </div>
                        
          <div class="col-md-12 mb-4">
            <p class=""><a href="contacto.php" class="btn btn-primary py-2 px-3 text-white rounded">Reservas y consultas</a></p> 
          </div>
              
            
        </div>
      </div>
    </div>    
      
      
      
      
      
      
      
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>