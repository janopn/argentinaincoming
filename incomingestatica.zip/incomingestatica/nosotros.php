<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   

    <div class="site-blocks-cover inner-page-cover" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">

            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h1 class="text-white font-weight-light">Sobre Nosotros</h1>
              
              
            </div>
          </div>
        </div>
      </div>  


<!--    
    <div class="site-section" data-aos="fade-up">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6 mb-5 mb-md-0">
            <img src="images/hero_bg_2.jpg" alt="Image" class="img-fluid rounded">
          </div>
          <div class="col-md-6 pl-md-5">
            <h2 class="font-weight-light text-black mb-4">Nuestra propuesta</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus.</p>

            <ul class="list-unstyled">
              <li class="d-flex align-items-center"><span class="icon-check2 text-primary h3 mr-2"></span><span>Vitae cumque eius modi expedita</span></li>
              <li class="d-flex align-items-center"><span class="icon-check2 text-primary h3 mr-2"></span><span>Totam at maxime Accusantium</span></li>
              <li class="d-flex align-items-center"><span class="icon-check2 text-primary h3 mr-2"></span><span>Distinctio temporibus</span></li>

            </ul>
          </div>
        </div>
      </div>
    </div>
-->


    <div class="site-section" data-aos="fade-up">
      <div class="container">
        <div class="row ">
          <div class="col-md-6  mb-md-0">
            <p>Argentina Incoming es una marca de Tresor Travel Empresa de Viajes y Turismo nacida en en el año 2020 con sede en Buenos Aires y dedicada especialmente a pasajeros que desean visitar nuestro hermoso país.</p>

 

<p>Tresor Travel comenzó en el año 2013, fundada por dos socios: Federico Paz y Germán Suárez. Ambos directores de la compañía, con una trayectoria de 12 años en la industria del turismo. Desde el comienzo, centraron sus fuerzas en el objetivo de ofrecer productos de vanguardia de todo el mundo.</p>

 

<p>La idea de crear esta nueva marca es explorar nuevos desafíos, brindando un servicio de calidad a nuestros pasajeros y agencias asociadas.</p>

<p>En la actualidad, existe una gran cantidad de sitios web que permiten crear tu propia experiencia de viaje, ofreciendo infinitas propuestas, esto hace que pierdas el objetivo de lo que realmente querías conocer.</p>

          </div>
          <div class="col-md-6 pl-md-5">

 


 

<p>Por el contrario, nuestro foco se centra en la atención personalizada y excelente planificación para que el viaje cumpla con tus expectativas. Ofreciendo productos exclusivos, asesoría y ofertas turísticas de calidad en nuestro país. Seleccionamos cuidadosamente a nuestros proveedores y nos destacamos por la confiable reputación que hemos logrado en estos años.</p>

 

<p>Te invitamos a que confíes en nuestra experiencia. Recibirás un contacto personalizado con nuestros especialistas, listos para ayudarte antes, durante y después de tu viaje.</p>

 



 
          </div>
        </div>
      </div>
    </div>








    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">¿POR QUE ELEGIRNOS?</h2>
            <p class="color-black-opacity-5">Lo que nos nos caracteriza</p>
          </div>
        </div>
        <div class="row align-items-stretch">

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Experiencia</h3>
                <p>Larga trayectoria en la industria del turismo</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Equipo de profesionales</h3>
                <p>Capacitados para satisfacer todas tus exigencias y necesidades</p>
              </div>
            </div>
          </div>
 
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Creatividad</h3>
                <p>Nos permite diseñar experiencias de viaje únicas</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Operadores locales</h3>
                <p>Cuidadosamente seleccionados para ofrecer productos exclusivos y ofertas turísticas de calidad en nuestro país</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Precio</h3>
                <p>Te asesoramos con las mejores ofertas del mercado</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Atención personalizada</h3>
                <p>Buscamos en todo momento tu satisfacción antes, durante y después del viaje</p>
              </div>
            </div>
          </div>
          

        </div>
      </div>
    </div>






    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-5 font-weight-light text-black">¿QUERÉS VIAJAR CON NOSOTROS?</h2>
            <p class="mb-0"><a href="contacto.php" class="btn btn-primary py-3 px-5 text-white rounded">¡Consultanos!</a></p>
          </div>
        </div>
      </div>
    </div>
   
   
   
    
 
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>