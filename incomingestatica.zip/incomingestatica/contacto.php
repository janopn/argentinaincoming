<!DOCTYPE html>
<html lang="en">
<?php include 'head.html'; ?>
  <body>
  <div class="site-wrap">
    <?php include 'menu.html';?>
    <?php include 'incompleteMandatoryFields.html'; ?>
    <div class="site-blocks-cover inner-page-cover" style="background-image: url(images/hero_bg_2.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h1 class="text-white font-weight-light">¡Contactanos!</h1>
            </div>
          </div>
        </div>
    </div>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-7 mb-5">
            <form action="thanks.php" method="post" name="Form" class="p-5 bg-white" onsubmit="return processForm();">
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">Nombre</label>
                  <input type="text" id="fname" name="fname" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Apellido</label>
                  <input type="text" id="lname" name="lname" class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="cant">Cantidad de pasajeros</label> 
                  <input type="cant" id="cant" name="cant" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="ltel">Teléfono</label>
                  <input type="text" id="ltel" name="ltel" class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="email">E-Mail</label> 
                  <input type="email" id="email" name="email" class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="message">Mensaje</label> 
                  <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="¿Que te gustaría consultarnos?"></textarea>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                  <div class="g-recaptcha" id="g-recaptcha" data-sitekey="6LcXqZEgAAAAADRZaOX7dYjZ2HSFwMJq_ZU6iNuV"></div>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                <input type="hidden" id="hdnsource" name="hdnsource" value="contacto">
                  <input type="submit" value="Enviar" class="btn btn-primary py-2 px-4 text-white rounded">
                </div>
              </div>
            </form>
          </div>
          <div class="col-md-5">
            <div class="p-4 mb-3 bg-white">
              <p class="mb-0 font-weight-bold">Argentina Incomig</p>
              <p class="mb-0">Somos el área de turismo receptivo de Tresor Travel. <strong>Legajo Nº 15705</strong></p>
              <p class="">Agencia habilitada por el Ministerio de Turismo de Argentina: <a href="https://www.argentina.gob.ar/turismoydeportes/turista/agencias-de-viajes-autorizadas" target="_blank">Ver agencias habilitadas</a></p>
              <p class="mb-0 font-weight-bold">Dirección</p>
              <p class="mb-4">Av. Corrientes 6365 Of 606. Ciudad Autónoma de Buenos Aires. Argentina    </p>
              <p class="mb-0 font-weight-bold">Teléfono</p>
              <p class="mb-4"><a href="#">+54 11 5365 7800</a></p>
              <p class="mb-0 font-weight-bold">Mail</p>
              <p class="mb-0"><a href="mailto:info@argentinaincoming.com.ar">info@argentinaincoming.com.ar</a></p>
            </div>
            <div class="p-4 mb-3 bg-white">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.562821186119!2d-58.45100178518633!3d-34.58992696427468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5f0e271e7ed%3A0x24a8f16aa5f16621!2sAv.%20Corrientes%206365%2C%20Buenos%20Aires!5e0!3m2!1ses-419!2sar!4v1588179875805!5m2!1ses-419!2sar" width="100%" height="auto" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" class="mb-4"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.html';?>
  </div>
  <?php include 'scripts.html';?>
  </body>
  <script src="validate.js"></script>
  <script type="text/javascript">
    function processForm() {
      fnameValidation = validateField("fname");
      emailValidation = validateField("email");
      recaptchaValidation = grecaptcha.getResponse() != "";

      isValid = fnameValidation && emailValidation && recaptchaValidation;

      if(!isValid){
        $('#myModal').modal();
      }

      return isValid;
    }
  </script>
</html>