<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   
      

    <div class="slide-one-item home-slider owl-carousel">
      

      <!--  
      <div class="site-blocks-cover" data-aos="fade" data-stellar-background-ratio="0.5"> 
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <video id="videoslider" src="videos/monopatin.mp4" autoplay muted loop></video>  
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Scooting BA</h1>
              <p class="mb-4 text-white">Conocé los exclusivos barrios de Recoleta y Palermo con nuestro fabuloso tour guiado en monopatín eléctrico.</p>
              <p class=""><a href="experiencia1601.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver experiencia</a></p>
            </div>
          </div>
        </div>
      </div>  
      -->    
                
      <!--  
      <div class="site-blocks-cover " style="background-image: url(images/slidercatedral.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Ski en Cerro Catedral</h1>
              <p class="mb-4 text-white">No te pierdas uno de los centros de ski más importante de Argentina. Alojate en la base del cerro o en la ciudad de Bariloche.</p>
              <p class=""><a href="destino20.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  
      -->
        
      <div class="site-blocks-cover " style="background-image: url(images/sliderba.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Buenos Aires</h1>
              <p class="mb-4 text-white">Preparate para conocer una ciudad única, llena de atractivos. Cultura, diversión y gastronomía te esperan para disfrutarla.</p>
              <p class=""><a href="destino16.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  

      <!--    
      <div class="site-blocks-cover " style="background-image: url(images/slidercastor.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Ski en Cerro Castor</h1>
              <p class="mb-4 text-white">Cercano de la ciudad de Ushuaia, es el centro invernal más Austral del mundo. Vení a disfrutar del ski en un entorno natural indescriptible.</p>
              <p class=""><a href="destino24.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  
      -->  
        
      <div class="site-blocks-cover " style="background-image: url(images/sliderbariloche.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Bariloche</h1>
              <p class="mb-4 text-white">Puerta de entrada a la Patagonia, Bariloche es el destino ideal si buscás lagos, montañas, aventura y comidas regionales.</p>
              <p class=""><a href="destino20.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  
        
      <div class="site-blocks-cover " style="background-image: url(images/slideriguazu.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Iguazú</h1>
              <p class="mb-4 text-white">Visitá las majestuosas cataratas del Iguazú: una de las siete maravillas naturales del mundo y, sin dudas, uno de los lugares más espectaculares de Latinoamérica.</p>
              <p class=""><a href="destino17.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  

      <div class="site-blocks-cover " style="background-image: url(images/slidercalafate.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-8 col-md-7  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">El Calafate</h1>
              <p class="mb-4 text-white">Uno de los lugares fascinantes de la Patagonia Argentina. Imperdible la visita al Lago Argentino y el Glaciar Perito Moreno.</p>
              <p class=""><a href="destino22.php" class="btn btn-primary py-2 px-3 text-white rounded">Ver destino</a></p>
            </div>
          </div>
        </div>
      </div>  

        
    </div>







    
 
    <div class="site-section ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-12 text-center">
            <h2 class="font-weight-light text-black">NUESTROS TOURS DESTACADOS</h2>
          </div>
        </div>

        <div class="row">

  
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0008.php" class="unit-2  rounded text-center">
              <img src="images/000801.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Perlas de Sudamérica</h4>
                <h6 class=" mb-0">Buenos Aires, Cusco, Machu Picchu, Lima y Río de Janeiro</h6>
                <h6 class=" mb-0 mt-1 text-black">14 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 4500</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0009.php" class="unit-2  rounded text-center">
              <img src="images/000901.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Sudamérica con Colombia</h4>
                <h6 class=" mb-0">Buenos Aires, Cusco, Machu Picchu, Lima, Cartagena y Río de Janeiro</h6>
                <h6 class=" mb-0 mt-1 text-black">18 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 5500</strong>
              </div>
            </a>
          </div>
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1601.php" class="unit-2  rounded text-center">
              <img src="images/160101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Buenos Aires de Lujo</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
     <!--             <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">-->
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 300</strong>
              </div>
            </a>
          </div>
            
    
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2405.php" class="unit-2  rounded text-center">
              <img src="images/240501.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Calafate & Ushuaia</h4>
                <h6 class=" mb-0 text-black">4 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 720</strong>
              </div>
            </a>
          </div>
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1701.php" class="unit-2  rounded text-center">
              <img src="images/170101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
       <!--           <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">-->
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 240</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2007.php" class="unit-2  rounded text-center">
              <img src="images/200701.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Bariloche</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 360</strong>
              </div>
            </a>
          </div>
            
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2201.php" class="unit-2  rounded text-center">
              <img src="images/220101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">El Calafate</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 400</strong>
              </div>
            </a>
          </div>
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1602.php" class="unit-2  rounded text-center">
              <img src="images/160202.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Buenos Aires, El Calafate e Iguazú</h4>
                <h6 class=" mb-0 text-black">7 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1500</strong>
              </div>
            </a>
          </div>
            

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2404.php" class="unit-2  rounded text-center">
              <img src="images/240401.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Ushuaia</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 410</strong>
              </div>
            </a>
          </div>
                
            
            
    
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1902.php" class="unit-2  rounded text-center">
              <img src="images/190201.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Mendoza</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
 <!--                 <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">-->
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 400</strong>
              </div>
            </a>
          </div>
            
            
            
            
        </div>
      
      </div>
      
      
        
        
      <div class="container">  
                
        <div class="row justify-content-center mb-5 mt-4">
          <div class="col-md-12 text-center">
            <h2 class="font-weight-light text-black">NUESTRAS EXPERIENCIAS DESTACADAS</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1601.php" class="unit-2  rounded text-center">
              <img src="images/e160101.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Scooting BA - Recoleta & Palermo</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 40</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1602.php" class="unit-2  rounded text-center">
              <img src="images/e160201.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Buenos Aires al Sur</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">Tarifa TOTAL del tour (hasta 5 pasajeros)</strong>
                  <strong class=" m-0 d-block precio">u$d 200</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1603.php" class="unit-2  rounded text-center">
              <img src="images/e160301.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Buenos Aires al Norte</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">Tarifa TOTAL del tour (hasta 5 pasajeros)</strong>
                  <strong class=" m-0 d-block precio">u$d 200</strong>
              </div>
            </a>
          </div>
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia1604.php" class="unit-2  rounded text-center">
              <img src="images/e160401.jpg" alt="Image" class="img-fluid " />
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Bodega Gamboa</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline" />
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline" />
                  <img src="iconos/vino_n.svg" alt="Degustacion" height="26px" class="m-0 d-inline" />
                  <img src="iconos/comida_n.svg" alt="Comida" height="26px" class="m-0 d-inline" />   
                </div>
              </div> 
              <hr class="m-0" />
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 120</strong>
              </div>
            </a>
          </div>

            
            

        </div>
        
        
      </div>
      
        


            
        
        
    </div>
    
    
    


    <div class="slide-one-item home-slider owl-carousel">

   
      <div class="site-blocks-cover " style="background-image: url(images/slidermapa.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
          
            <div class="col-8 col-md-6  transparente rounded pt-4" >
              <h1 class="text-white font-weight-normal ">Creá tu experiencia</h1>
              <p class="mb-4 text-white">Nuestro equipo de expertos te ayudará a crear tu experiencia a medida para que vivas un viaje único.</p>
              <p class=""><a href="creaexp.php" class="btn btn-primary py-2 px-3 text-white rounded">¡Ingresá!</a></p>
            </div>
          </div>
        </div>
      </div>  
   
   
      
    </div>


    
    
    
    <div class="site-section">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">¿POR QUE ELEGIRNOS?</h2>
            <p class="color-black-opacity-5">Lo que nos nos caracteriza</p>
          </div>
        </div>
        <div class="row align-items-stretch">

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Experiencia</h3>
                <p>Larga trayectoria en la industria del turismo</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Equipo de profesionales</h3>
                <p>Capacitados para satisfacer todas tus exigencias y necesidades</p>
              </div>
            </div>
          </div>
 
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Creatividad</h3>
                <p>Nos permite diseñar experiencias de viaje únicas</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Operadores locales</h3>
                <p>Cuidadosamente seleccionados para ofrecer productos exclusivos y ofertas turísticas de calidad en nuestro país</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Precio</h3>
                <p>Te asesoramos con las mejores ofertas del mercado</p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <span class="icon-check2 text-primary h2 mr-2"></span>
              <div>
                <h3 class="mt-2">Atención personalizada</h3>
                <p>Buscamos en todo momento tu satisfacción antes, durante y después del viaje</p>
              </div>
            </div>
          </div>
          

        </div>
      </div>
    </div>
    
    
    
    
    
    
    
    <div class="site-section bg-light">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-5 font-weight-light text-black">¿QUERÉS VIAJAR CON NOSOTROS?</h2>
            <p class="mb-0"><a href="contacto.php" class="btn btn-primary py-3 px-5 text-white rounded">¡Consultanos!</a></p>
          </div>
        </div>
      </div>
    </div>
   
  
  
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios" />
          </div>
         </div>
      </div>
    </div>
   
   
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
    
  </body>
</html>