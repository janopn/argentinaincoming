<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '/home/mike/vendor/autoload.php';

function sendEmail($subject, $body){
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->SMTPAuth = true;
    $mail->Username = "consultasweb@argentinaincoming.com.ar";
    $mail->Password = "bewsatlusnoc";
    $mail->setFrom("consultasweb@argentinaincoming.com.ar", "Consulta Web Argentina Incoming");
    $mail->addAddress("info@argentinaincoming.com.ar", "Info Argentina Incoming");
    $mail->Subject = $subject;
    $mail->msgHTML($body);
  
    $error = false;
  
    if(!$mail->send()){
        echo "Mailer Error: " . $mail->ErrorInfo;
        $error = true;
    }
  
    return $error;
  }
  
  function valueOrEmpty($name){
    if(isset($_POST)){
      $post = $_POST[$name];
      if(isset($post)) {
        if(is_array($post)){
          return implode("; ", $post);
        }
        return $post;
      }
    }
    return "";
  }

  function printOK(){
    echo <<<EOD
    <div class="row bg-light">
      <div class="col-sm-12 mt-4 pl-3">
        <div class="alert alert-success px-3 py-4">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
          </button>
          <h5 class="">El mensaje se ha enviado correctamente, te responderemos a la brevedad. ¡Muchas  gracias!</h5>
        </div>
      </div>
    </div>
    EOD;
  }

  function printERROR(){
    echo <<<EOD
    <div class="row bg-light">
      <div class="col-sm-12 mt-4 pl-3">
        <div class="alert alert-danger px-3 py-4">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
          </button>
          <h5 class="">Ha ocurrido un error enviando el mensaje. Por favor, reintente más tarde.</h5>
        </div>
      </div>
    </div>
    EOD;
  }
  ?>