<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   







  
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12 pl-lg-5">
            <h2 class="font-weight-light text-white mb-4">Mendoza</h2>
            <p class="text-white">Mendoza es una ciudad de la región de Cuyo en Argentina y es el corazón de la zona vitivinícola argentina, famosa por sus Malbecs y otros vinos tintos. Sus distintas bodegas ofrecen degustaciones y visitas guiadas. La ciudad tiene calles amplias y frondosas rodeadas de edificios modernos y art déco, y con plazas más pequeñas que rodean la Plaza Independencia, sitio del Museo Municipal de Arte Moderno subterráneo, que exhibe arte moderno y contemporáneo.</p>
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/19_1.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/19_2.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/19_3.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>

   



    <div class="site-section ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS EN MENDOZA</h2>
          </div>
        </div>

        <div class="row">


            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1902.php" class="unit-2  rounded text-center">
              <img src="images/190201.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Mendoza</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
 <!--                 <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">-->
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 400</strong>
              </div>
            </a>
          </div>
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1901.php" class="unit-2  rounded text-center">
              <img src="images/190101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Mendoza Hospedagem entre vinhas</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 600</strong>
              </div>
            </a>
          </div>




        </div>
      
      </div>
        
      <!--
      <div class="container">  
        
        
        <div class="row justify-content-center mb-5 mt-4">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">EXPERIENCIAS EN MENDOZA</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/mujer2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">City Tour Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 290</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


        </div>
        
        
        
        
        
        
      </div>
      -->

      
    </div>    
      
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>