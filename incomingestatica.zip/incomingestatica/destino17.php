<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   







  
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12 pl-lg-5">
            <h2 class="font-weight-light text-white mb-4">Puerto Iguazú</h2>
            <p class="text-white">Patrimonio natural de la humanidad desde 1984 y una de las 7 maravillas naturales del mundo desde 2011, el Parque Nacional Iguazú es un universo natural único. Lleno de vida, abundante vegetación y 275 saltos, entre ellos la Garganta del Diablo, cayendo a 82 metros de altura, es el lugar ideal para conectar con la naturaleza. A través de pasarelas, adaptadas a sillas de ruedas y cochecitos de bebé, puedes disfrutar de los Saltos y La Selva Misionera de cerca. Porque vivir la naturaleza en el Parque es una experiencia accesible a todos.</p>
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/17_1.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/17_2.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/17_3.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>

   



    <div class="site-section ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS EN PUERTO IGUAZÚ</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1701.php" class="unit-2  rounded text-center">
              <img src="images/170101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
       <!--           <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">-->
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 240</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1702.php" class="unit-2  rounded text-center">
              <img src="images/170201.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Iguazú de Lujo</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 610</strong>
              </div>
            </a>
          </div>
            
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa1602.php" class="unit-2  rounded text-center">
              <img src="images/160203.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Buenos Aires, El Calafate e Iguazú</h4>
                <h6 class=" mb-0 text-black">7 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1500</strong>
              </div>
            </a>
          </div>




        </div>
      
      </div>
        
        
        
        
        
      <!--
      <div class="container">  
        
        
        <div class="row justify-content-center mb-5 mt-4">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">EXPERIENCIAS EN PUERTO IGUAZÚ</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/mujer2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">City Tour Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 290</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


        </div>
        
        
        
        
        
        
      </div>
      -->
        
    </div>    
      
      
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>