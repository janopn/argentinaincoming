<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">Cataratas del Iguazú</h2>
            <h5 class="font-weight-light text-white mb-1">3 Noches</h2>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline">
              <img src="iconos/excursion_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline">
            </div>                
 
 
 
            <ul class="text-white pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>Alojamiento en el Hotel Cataratas Resort con régimen de desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  
 
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slideriguazu.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/sliderbariloche.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>
	  
	  
	  
	  
	  
  
    
    <div class="site-section">
      <div class="container">

        <form action="reservatour.php" class="">

		  
		  <div class="row bg-light">
			  			  
            <div class="col-lg-3 border-right mt-4 pt-3 pl-4">
              <strong class="text-primary mb-1 d-block precio">Total reserva:</strong> 
              <strong class="text-primary preciodestacado d-block mb-1">u$d 4690</strong>
              <strong class="text-primary legal d-block ">Tarifa total por 6 pasajeros</strong>
			</div>
			  
			  
            <div class="col-lg-9 ">
			
    		  <div class="row bg-light ">
			  			  
                <div class="col-md-12 mt-4 ml-2">
	    			<h3 class="font-weight-light azul">¡Sumá experiencias a tu viaje!</h3>
					<h6 class="mb-2" >Agregá las acividades que quieras realizar en tu estadía</h6>			
                </div>
    		  </div>	  			 
			  
			
    		  <div class="row bg-light ">			  
                <div class="col-12 col-lg-6 mt-3 px-4">
    	  	      <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">Paso 3 de 4</div>
                  </div>				
    			</div>

				<div class="col-6 col-lg-3 mt-1 pl-4 ">  
                    <input type="submit" value="Volver" class="btn btn-primary text-white rounded ancho ">
    			</div> 		 
				  
				<div class="col-6 col-lg-3 mt-1 pr-4 ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho">
    			</div> 		 
			  
    		  </div>	
			</div>

		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr>								
            </div>
		  </div>	
		  
		  
		  
		  

        <div class="row bg-light">

          
          
          
          
          <div class="col-lg-8 mb-5 p-4 border-right">

           

 
<!--inicio experiencias en un destino-->
            <h4 class="panel-title mb-4">
              <a data-toggle="collapse" href="#collapse1">Experiencias en Iguazú<span class="icon-plus-circle iconomas mt-1 float-right"></a>
            </h4>
            <div id="collapse1" class="panel-collapse collapse">

<!--cuadro experiencia-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">
                  
                  <!--inicio slider-->
                  <div id="carouselExampleIndicators1" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators1" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators1" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators1" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                
                   
                </div>
                <div class="col-md-7  p-2 pl-3">
                  <div class="mb-0">
                    <h5 class=" d-inline">Paseo en bici</h5>
                  </div> 
                  <div class="mb-0 ">
                    <h6 class=" atributohotel">Ideal para familias</h6>
                    <h6 class=" atributohotel">Eco Tour</h6>
                  </div>                   
                  <div class="mb-1">
                    <img src="iconos/bus_n.svg" alt="Traslado" width="28px" class="m-0 d-inline">
                    <img src="iconos/barco_n.svg" alt="Navegacion" width="28px" class="m-0 d-inline">
                    <img src="iconos/bici_n.svg" alt="Excursiones" width="28px" class="m-0 d-inline">
                    <img src="iconos/comida_n.svg" alt="Comida" width="28px" class="m-0 d-inline">
                  </div>    
                  <div class="mb-1 hab">            
                    <input type="number" id="exp1" name="exp1" min="0" max="20" value="0">
                    <label for="exp1">pasajero/s</label>
                  </div>
                  <strong class="text-primary precioexp d-block">u$d 190</strong>
                  <strong class="text-primary legal d-block">Tarifa final por pasajero</strong>


                  <div class="mt-1">
                    <div class=" d-inline ">         
                      <span class="icon-info-circle colormarca "></span>   
                    </div>
                    <a  class=" d-inline hab " href="#"  data-toggle="modal" data-target="#ventanamodal1">Ver más info de la experiencia</a>
                  </div>

                  <!-- Modal -->
                  <div class="modal fade" id="ventanamodal1" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modallabel">Detalle de experiencia</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <h2 class="font-weight-light mb-2">City Tour Panorámico</h2>
                          <h5 class="font-weight-light mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
                          <div class="mb-3">
                            <img src="iconos/bus_n.svg" alt="Traslado" width="36px" class="m-0 d-inline">
                            <img src="iconos/barco_n.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
                            <img src="iconos/bici_n.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
                            <img src="iconos/comida_n.svg" alt="Comida" width="36px" class="m-0 d-inline">
                          </div>                
                          <ul class=" pl-3 mb-4">
                            <li>Bus turistico</li>
                            <li>4 descensos</li>
                            <li>Almuerzo (sin bebidas)</li>
                          </ul>  
                          <p class="font-weight-light mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
                          <p class="font-weight-light mb-0"><strong>Duración:</strong> 8 hs.</p>            
                          <strong class="d-inline mb-4">Idiomas disponibles:</strong>
                          <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
                          <h3 class="font-weight-light mb-2">Itinerario</h2>
                          <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
                          </p>

                        </div>
                      </div>
                    </div>
                  </div>                           
                  <!--fin modal-->

                </div>                
              </div>
<!--fin cuadro experiencia-->
   
<!--cuadro experiencia-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">
                  <!--inicio slider-->
                  <div id="carouselExampleIndicators2" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators2" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators2" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators2" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators2" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators2" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                
                </div>
                <div class="col-md-7  p-2 pl-3">
                  <div class="mb-0">
                    <h5 class=" d-inline">City Tour con visita al museo</h5>
                  </div> 
                  <div class="mb-0 ">
                    <h6 class=" atributohotel">Ideal para familias</h6>
                    <h6 class=" atributohotel">Eco Tour</h6>
                  </div>                   
                  <div class="mb-1">
                    <img src="iconos/bus_n.svg" alt="Traslado" width="28px" class="m-0 d-inline">
                    <img src="iconos/barco_n.svg" alt="Navegacion" width="28px" class="m-0 d-inline">
                    <img src="iconos/bici_n.svg" alt="Excursiones" width="28px" class="m-0 d-inline">
                    <img src="iconos/comida_n.svg" alt="Comida" width="28px" class="m-0 d-inline">
                  </div>    
                  <div class="mb-1 hab">            
                    <input type="number" id="exp2" name="exp1" min="0" max="20" value="0">
                    <label for="exp2">pasajero/s</label>
                  </div>
                  <strong class="text-primary precioexp d-block">u$d 290</strong>
                  <strong class="text-primary legal d-block">Tarifa final por pasajero</strong>
                  
                  <div class="mt-1">
                    <div class=" d-inline ">         
                      <span class="icon-info-circle colormarca "></span>   
                    </div>
                    <a  class=" d-inline hab " href="#"  data-toggle="modal" data-target="#ventanamodal2">Ver más info de la experiencia</a>
                  </div>

                  <!-- Modal -->
                  <div class="modal fade" id="ventanamodal2" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modallabel">Detalle de experiencia</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <h2 class="font-weight-light mb-2">City Tour Panorámico</h2>
                          <h5 class="font-weight-light mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
                          <div class="mb-3">
                            <img src="iconos/bus_n.svg" alt="Traslado" width="36px" class="m-0 d-inline">
                            <img src="iconos/barco_n.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
                            <img src="iconos/bici_n.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
                            <img src="iconos/comida_n.svg" alt="Comida" width="36px" class="m-0 d-inline">
                          </div>                
                          <ul class=" pl-3 mb-4">
                            <li>Bus turistico</li>
                            <li>4 descensos</li>
                            <li>Almuerzo (sin bebidas)</li>
                          </ul>  
                          <p class="font-weight-light mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
                          <p class="font-weight-light mb-0"><strong>Duración:</strong> 8 hs.</p>            
                          <strong class="d-inline mb-4">Idiomas disponibles:</strong>
                          <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
                          <h3 class="font-weight-light mb-2">Itinerario</h2>
                          <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
                          </p>

                        </div>
                      </div>
                    </div>
                  </div>                           
                  <!--fin modal-->
                  
                </div>
              </div>
<!--fin cuadro experiencia-->


            </div>
<!--fin experiencias en un destino-->            


            <hr/>




<!--inicio experiencias en un destino-->
            <h4 class="panel-title mb-4">
              <a data-toggle="collapse" href="#collapse2">Experiencias en Salta<span class="icon-plus-circle iconomas mt-1 float-right"></a>
            </h4>
            <div id="collapse2" class="panel-collapse collapse">

<!--cuadro experiencia-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">
                  <!--inicio slider-->
                  <div id="carouselExampleIndicators3" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators3" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators3" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators3" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators3" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators3" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                
                </div>
                <div class="col-md-7  p-2 pl-3">
                  <div class="mb-0">
                    <h5 class=" d-inline">Paseo en bici</h5>
                  </div> 
                  <div class="mb-0 ">
                    <h6 class=" atributohotel">Ideal para familias</h6>
                    <h6 class=" atributohotel">Eco Tour</h6>
                  </div>                   
                  <div class="mb-1">
                    <img src="iconos/bus_n.svg" alt="Traslado" width="28px" class="m-0 d-inline">
                    <img src="iconos/barco_n.svg" alt="Navegacion" width="28px" class="m-0 d-inline">
                    <img src="iconos/bici_n.svg" alt="Excursiones" width="28px" class="m-0 d-inline">
                    <img src="iconos/comida_n.svg" alt="Comida" width="28px" class="m-0 d-inline">
                  </div>    
                  <div class="mb-1 hab">            
                    <input type="number" id="exp3" name="exp1" min="0" max="20" value="0">
                    <label for="exp3">pasajero/s</label>
                  </div>
                  <strong class="text-primary precioexp d-block">u$d 190</strong>
                  <strong class="text-primary legal d-block">Tarifa final por pasajero</strong>
                  
                  <div class="mt-1">
                    <div class=" d-inline ">         
                      <span class="icon-info-circle colormarca "></span>   
                    </div>
                    <a  class=" d-inline hab " href="#"  data-toggle="modal" data-target="#ventanamodal3">Ver más info de la experiencia</a>
                  </div>

                  <!-- Modal -->
                  <div class="modal fade" id="ventanamodal3" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modallabel">Detalle de experiencia</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <h2 class="font-weight-light mb-2">City Tour Panorámico</h2>
                          <h5 class="font-weight-light mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
                          <div class="mb-3">
                            <img src="iconos/bus_n.svg" alt="Traslado" width="36px" class="m-0 d-inline">
                            <img src="iconos/barco_n.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
                            <img src="iconos/bici_n.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
                            <img src="iconos/comida_n.svg" alt="Comida" width="36px" class="m-0 d-inline">
                          </div>                
                          <ul class=" pl-3 mb-4">
                            <li>Bus turistico</li>
                            <li>4 descensos</li>
                            <li>Almuerzo (sin bebidas)</li>
                          </ul>  
                          <p class="font-weight-light mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
                          <p class="font-weight-light mb-0"><strong>Duración:</strong> 8 hs.</p>            
                          <strong class="d-inline mb-4">Idiomas disponibles:</strong>
                          <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
                          <h3 class="font-weight-light mb-2">Itinerario</h2>
                          <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
                          </p>

                        </div>
                      </div>
                    </div>
                  </div>                           
                  <!--fin modal-->
                  
                </div>
              </div>
<!--fin cuadro experiencia-->
   
<!--cuadro experiencia-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">
                  <!--inicio slider-->
                  <div id="carouselExampleIndicators4" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators4" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators4" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators4" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators4" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators4" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                
                </div>
                <div class="col-md-7  p-2 pl-3">
                  <div class="mb-0">
                    <h5 class=" d-inline">City Tour con visita al museo</h5>
                  </div> 
                  <div class="mb-0 ">
                    <h6 class=" atributohotel">Ideal para familias</h6>
                    <h6 class=" atributohotel">Eco Tour</h6>
                  </div>                   
                  <div class="mb-1">
                    <img src="iconos/bus_n.svg" alt="Traslado" width="28px" class="m-0 d-inline">
                    <img src="iconos/barco_n.svg" alt="Navegacion" width="28px" class="m-0 d-inline">
                    <img src="iconos/bici_n.svg" alt="Excursiones" width="28px" class="m-0 d-inline">
                    <img src="iconos/comida_n.svg" alt="Comida" width="28px" class="m-0 d-inline">
                  </div>    
                  <div class="mb-1 hab">            
                    <input type="number" id="exp4" name="exp1" min="0" max="20" value="0">
                    <label for="exp4">pasajero/s</label>
                  </div>
                  <strong class="text-primary precioexp d-block">u$d 290</strong>
                  <strong class="text-primary legal d-block">Tarifa final por pasajero</strong>
                  
                  <div class="mt-1">
                    <div class=" d-inline ">         
                      <span class="icon-info-circle colormarca "></span>   
                    </div>
                    <a  class=" d-inline hab " href="#"  data-toggle="modal" data-target="#ventanamodal4">Ver más info de la experiencia</a>
                  </div>

                  <!-- Modal -->
                  <div class="modal fade" id="ventanamodal4" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modallabel">Detalle de experiencia</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                          <h2 class="font-weight-light mb-2">City Tour Panorámico</h2>
                          <h5 class="font-weight-light mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
                          <div class="mb-3">
                            <img src="iconos/bus_n.svg" alt="Traslado" width="36px" class="m-0 d-inline">
                            <img src="iconos/barco_n.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
                            <img src="iconos/bici_n.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
                            <img src="iconos/comida_n.svg" alt="Comida" width="36px" class="m-0 d-inline">
                          </div>                
                          <ul class=" pl-3 mb-4">
                            <li>Bus turistico</li>
                            <li>4 descensos</li>
                            <li>Almuerzo (sin bebidas)</li>
                          </ul>  
                          <p class="font-weight-light mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
                          <p class="font-weight-light mb-0"><strong>Duración:</strong> 8 hs.</p>            
                          <strong class="d-inline mb-4">Idiomas disponibles:</strong>
                          <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
                          <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
                          <h3 class="font-weight-light mb-2">Itinerario</h2>
                          <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
                          </p>

                        </div>
                      </div>
                    </div>
                  </div>                           
                  <!--fin modal-->
                  
                </div>
              </div>
<!--fin cuadro experiencia-->


            </div>
<!--fin experiencias en un destino-->            


  
          </div>
                   
   
		  <div class="col-lg-4 p-4 ">
 			  
            <strong class="text-primary mb-4 mt-1 d-block precio">Resumen de la reserva</strong> 
			  			  
            <h3 class="font-weight-light mb-2">Cataratas del Iguazú</h3>
            <h5 class="font-weight-light mb-3">3 Noches</h5>
 
 
            <label class="text-black mb-1" for="hab">Fecha de viaje</label>
            <p class="m-0">Desde: 01/07/2020</p>
            <p class="mb-3">Hasta: 08/07/2020</p>
 

            <label class="text-black mb-0" for="hab">Servicios incluidos</label>
            <div class="mb-1">
              <img src="iconos/avion_n.svg" alt="Vuelo" width="30px" class="m-0 d-inline">
              <img src="iconos/bus_n.svg" alt="Traslado" width="30px" class="m-0 d-inline">
              <img src="iconos/hotel_n.svg" alt="Alojamiento" width="30px" class="m-0 d-inline">
              <img src="iconos/excursion_n.svg" alt="Excursiones" width="30px" class="m-0 d-inline">
              <img src="iconos/asistencia_n.svg" alt="Asistencia" width="30px" class="m-0 d-inline">
            </div>                 
            <ul class=" pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>3 noches de alojamiento en Iguazú con desayuno</li>
              <li>2 noches de alojamiento en Salta con desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  

            <div class="mb-3">
              <label class="text-black mb-0 d-block" >Hotel/es seleccionado/s:</label>
              <div>
                <p class=" d-inline m-0">Sheraton Cataratas</p>
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
              </div>
              <div>
                <p class=" d-inline m-0">Salta Resort & Spa</p>
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
              </div>
            </div>


            <label class="text-black mb-0" for="hab">Habitaciones</label>
            <div>
              <p class=" d-inline">- Habitación 1: 2 adultos y 2 menores</p>
            </div>
            <div>
              <p class=" d-inline">- Habitación 2: 4 adultos</p>
            </div>

 
            <label class="text-black mb-0 mt-3" for="hab">Viaja con bebés: Si</label>
 
        

            <hr/>

            <h5 class="mb-2 mt-4">Experiencias adicionales</h5>
            <p class="m-0">- Paseo en bici (3 pasajeros)</p>
            <p>- City Tour (2 pasajeros)</p>

          </div>	  
			  
			  
			  
          
        </div>
        
        </form>
        
        
      </div>
    </div>    
    
    
		  
		  
		  
		  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h2>
 
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 1</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio <a href="experiencia.php" class=" d-inline subrayado">City Tour Panorámico</a> illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur <a href="experiencia.php" class="d-inline subrayado">Paseo en bici</a> adipisicing elit.</p>
                                
              </div>                
            </div>
            
            <hr>
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 2</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus <a href="experiencia.php" class=" d-inline subrayado">Visita a bodega Zucardi</a> alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>
            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 3</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>

              </div>                
            </div>

            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 4</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>


          </div>
          
          
          
        </div>
      </div>
    </div>    
		  
		  
		  
		  
		  
		  
		  
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>