<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   







  
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12 pl-lg-5">
            <h2 class="font-weight-light text-white mb-4">Bariloche</h2>
            <p class="text-white">Bariloche es una ciudad ubicada entre bosques milenarios, montañas cubiertas de nieve y lagos cristalinos, en la provincia de Río Negro, Argentina. Se trata de una postal de nuestra Patagonia. Una ciudad anfitriona por excelencia, enmarcada por algunas de las bellezas naturales más importantes del país. 
Se puede disfrutar variedad de actividades: excursiones tradicionales, nieve para todos los gustos, la mejor gastronomía, actividades familiares, aventura, tranquilidad y una agenda cultural diversa.</p>
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/20_1.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/20_2.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/20_3.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>

   



    <div class="site-section ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS EN BARILOCHE</h2>
          </div>
        </div>

        <div class="row">
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2007.php" class="unit-2  rounded text-center">
              <img src="images/200701.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Bariloche</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 360</strong>
              </div>
            </a>
          </div>
            
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2006.php" class="unit-2  rounded text-center">
              <img src="images/200601.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Bariloche de Lujo</h4>
                <h6 class=" mb-0 text-black">2 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 510</strong>
              </div>
            </a>
          </div>
            
<!--            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2001.php" class="unit-2  rounded text-center">
              <img src="images/200101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Extraweek desde Buenos Aires</h4>
                <h6 class=" mb-0 text-black">5 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 850</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2002.php" class="unit-2  rounded text-center">
              <img src="images/200201.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Skiweek desde Buenos Aires</h4>
                <h6 class=" mb-0 text-black">7 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1140</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2003.php" class="unit-2  rounded text-center">
              <img src="images/200301.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Extraweek desde São Paulo</h4>
                <h6 class=" mb-0 text-black">5 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1400</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2004.php" class="unit-2  rounded text-center">
              <img src="images/200401.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Skiweek desde São Paulo</h4>
                <h6 class=" mb-0 text-black">7 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1700</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa2005.php" class="unit-2  rounded text-center">
              <img src="images/200501.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Miniweek desde Buenos Aires</h4>
                <h6 class=" mb-0 text-black">3 Noites</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 700</strong>
              </div>
            </a>
          </div>
          -->


        </div>
      
      </div>
      
        
        
    <!--    
      <div class="container">  
        
        
        <div class="row justify-content-center mb-5 mt-4">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">EXPERIENCIAS EN BARILOCHE</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/mujer2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">City Tour Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 290</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


        </div>        
        
        
      </div>
      -->  
        
        
        
    
    </div>  
      
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>