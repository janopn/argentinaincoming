<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   




   



    <div class="site-section ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS COMBINADOS</h2>
          </div>
        </div>

        <div class="row">

            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0008.php" class="unit-2  rounded text-center">
              <img src="images/000801.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Perlas de Sudamérica</h4>
                <h6 class=" mb-0">Buenos Aires, Cusco, Machu Picchu, Lima y Río de Janeiro</h6>
                <h6 class=" mb-0 mt-1 text-black">14 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 4500</strong>
              </div>
            </a>
          </div>
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0009.php" class="unit-2  rounded text-center">
              <img src="images/000901.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Sudamérica con Colombia</h4>
                <h6 class=" mb-0">Buenos Aires, Cusco, Machu Picchu, Lima, Cartagena y Río de Janeiro</h6>
                <h6 class=" mb-0 mt-1 text-black">18 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 5500</strong>
              </div>
            </a>
          </div>
            
            

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0002.php" class="unit-2  rounded text-center">
              <img src="images/000201.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Clásicos imperdibles</h4>
                <h6 class=" mb-0">Buenos Aires, Iguazú y El Calafate</h6>
                <h6 class=" mb-0 mt-1 text-black">7 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 800</strong>
              </div>
            </a>
          </div>
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0003.php" class="unit-2  rounded text-center">
              <img src="images/000301.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">BA + Patagonia Austral</h4>
                <h6 class=" mb-0">Buenos Aires, El Calafate y Ushuaia</h6>
                <h6 class=" mb-0 mt-1 text-black">7 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 980</strong>
              </div>
            </a>
          </div>

            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0004.php" class="unit-2  rounded text-center">
              <img src="images/000401.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Argentina esencial</h4>
                <h6 class=" mb-0">Buenos Aires, Iguazú, El Calafate y Ushuaia</h6>
                <h6 class=" mb-0 mt-1 text-black">9 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1200</strong>
              </div>
            </a>
          </div>
            
            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0005.php" class="unit-2  rounded text-center">
              <img src="images/000501.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">BA + Patagonia Full</h4>
                <h6 class=" mb-0">Buenos Aires, Bariloche, El Calafate, Ushuaia y Puerto Madryn</h6>
                <h6 class=" mb-0 mt-1 text-black">13 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1630</strong>
              </div>
            </a>
          </div>
          
          
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0006.php" class="unit-2  rounded text-center">
              <img src="images/000601.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">BA + Lagos y Glaciares</h4>
                <h6 class=" mb-0">Buenos Aires, Bariloche, El Calafate y Ushuaia</h6>
                <h6 class=" mb-0 mt-1 text-black">10 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1270</strong>
              </div>
            </a>
          </div>

            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0007.php" class="unit-2  rounded text-center">
              <img src="images/000701.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Argentina maravillosa</h4>
                <h6 class=" mb-0">Buenos Aires, Puerto Madryn, El Calafate e Iguazú</h6>
                <h6 class=" mb-0 mt-1 text-black">10 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 1140</strong>
              </div>
            </a>
          </div>

            
            
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa0001.php" class="unit-2  rounded text-center">
              <img src="images/000101.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-0">Argentina Full</h4>
                <h6 class=" mb-0">BA, Iguazú, Salta, Mendoza, Bariloche, Calafate, Ushuaia y Puerto Madryn</h6>
                <h6 class=" mb-0 mt-1 text-black">20 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Nagegacion" height="26px" class="m-0 d-inline">
                  <img src="iconos/vino_n.svg" alt="Bodega" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 2800</strong>
              </div>
            </a>
          </div>

            
            
                     
            

        </div>
      
      </div>
        
      
        
        
        
    
    </div>    
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>