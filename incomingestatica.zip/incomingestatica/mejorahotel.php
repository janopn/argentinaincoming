<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">Cataratas del Iguazú</h2>
            <h5 class="font-weight-light text-white mb-1">3 Noches</h2>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline">
              <img src="iconos/excursion_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline">
            </div>                
 
 
 
            <ul class="text-white pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>Alojamiento en el Hotel Cataratas Resort con régimen de desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  
 
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slideriguazu.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/sliderbariloche.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>
	  
	  
	  
	  
	  
  
    
    <div class="site-section">
      <div class="container">

        <form action="elegiexp.php" class="">

		  
		  <div class="row bg-light">
			  			  
            <div class="col-lg-3 border-right mt-4 pt-3 pl-4">
              <strong class="text-primary mb-1 d-block precio">Total reserva:</strong> 
              <strong class="text-primary preciodestacado d-block mb-1">u$d 4690</strong>
              <strong class="text-primary legal d-block ">Tarifa total por 6 pasajeros</strong>
			</div>
			  
			  
            <div class="col-lg-9 ">
			
    		  <div class="row bg-light ">
			  			  
                <div class="col-md-12 mt-4 ml-2">
	    			<h3 class="font-weight-light azul">¿Querés mejorar tu hotel?</h3>
					<h6 class="mb-2" >¡Elegí la opción que más te guste!</h6>			
                </div>
    		  </div>	  			 
			  
			
    		  <div class="row bg-light ">			  
                <div class="col-12 col-lg-6 mt-3 px-4">
    	  	      <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">Paso 2 de 4</div>
                  </div>				
    			</div>

				<div class="col-6 col-lg-3 mt-1 pl-4 ">  
                    <input type="submit" value="Volver" class="btn btn-primary text-white rounded ancho ">
    			</div> 		 
				  
				<div class="col-6 col-lg-3 mt-1 pr-4 ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho">
    			</div> 		 
			  
    		  </div>	
			</div>

		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr>								
            </div>
		  </div>	
		  
		  
		  
		  

        <div class="row bg-light">

          
          
          
          
          <div class="col-lg-8 mb-5 p-4 border-right">

           

 
 <!--inicio hoteles en un destino-->
            <h4 class="panel-title mb-4">
              <a data-toggle="collapse" href="#collapse1">Hoteles en Puerto Iguazú<span class="icon-plus-circle iconomas mt-1 float-right"></span>               
</a>
            </h4>
            <div id="collapse1" class="panel-collapse collapse">
             

              <div class="row form-group  ">               
                <div class="col-4 col-md-2 col-lg-4 col-xl-2 mb-3 mb-md-0">
                  <label class="mb-1 h5 mt-2" for="categoria">Categoría</label>
                </div>
                <div class="col-8 col-md-4 col-lg-8 col-xl-4 mb-3 mb-md-0">
                  <select name="categoria" class="form-control mb-3 ">
                    <option value="3est">3 estrellas</option>
                    <option value="4est">4 estrellas</option>
                    <option value="5est">5 estrellas</option>
                  </select>
                </div>
              
              </div>

<!--inicio hotel-->
              <div class="row form-group cuadrohotel rounded ml-0 mr-0">
                <div class="col-md-5  p-0">

                  <!--inicio slider-->
                  <div id="carouselExampleIndicators1" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators1" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators1" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators1" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                


                </div>


                <div class="col-md-7  p-2 pl-3">
                  <h5 class=" d-inline ">Hotel Cataratas</h5>

                  <div class="mb-0 mt-0">
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />

                    <div class="ml-2 d-inline mt-0">         
                      <span class="icon-map-marker iconolugar mb-0 "></span>               
                      <a  class=" hab " href="#"  data-toggle="modal" data-target="#ventanamodal1">Ver mapa</a>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="ventanamodal1" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="modallabel">Ubicación Hotel Cataratas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.5613229230457!2d-58.45098328521471!3d-34.589964864276716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5f0fd14568f%3A0xa13be2deb7ae0aab!2sAv.%20Corrientes%206365%2C%20Buenos%20Aires!5e0!3m2!1ses!2sar!4v1600214031270!5m2!1ses!2sar" width="468" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>            
                          </div>
                        </div>
                      </div>
                    </div>                  
                  </div> 

                  <div class="mb-2">
                    <h6 class=" atributohotel">Excelente ubicación</h6>
                    <h6 class=" atributohotel">Ideal familias</h6>
                    <h6 class=" atributohotel">Piscina climatizada</h6>
                  </div> 
                  
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab1" name="destino1" value="hab1" checked>
                      <label for="hab1">Habitación Standar</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 0</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab2" name="destino1" value="hab2" >
                      <label for="hab2">Habitación Superior</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 180</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab3" name="destino1" value="hab3" >
                      <label for="hab3">Suite</label>
                    </div>
                    <div class="col-4"> 
                      <strong class="text-primary ">+ u$d 240</strong>
                    </div>  
                  </div>
                  
                  <img class="d-inline mb-0" src="images/trip.svg" height="12px" />
                  <a class="hab" href="https://www.tripadvisor.com.ar/" target="_blank">Ver en TripAdvisor</a>
                  <p class="d-inline"> | </p>
                  <a class="hab" href="https://www.tresortravel.com.ar/" target="_blank">Visitar web del hotel</a>
                </div>
              </div>
<!--final hotel-->   
   
   
<!--inicio hotel-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">

                  <!--inicio slider-->
                  <div id="carouselExampleIndicators2" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators2" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators2" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators2" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators2" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators2" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                

                </div>
                <div class="col-md-7  p-2 pl-3">
                  <h5 class=" d-inline ">Hotel Iguazú</h5>

                  <div class="mb-0 mt-0">
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />

                    <div class="ml-2 d-inline mt-0">         
                      <span class="icon-map-marker iconolugar mb-0 "></span>               
                      <a  class=" hab " href="#"  data-toggle="modal" data-target="#ventanamodal2">Ver mapa</a>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="ventanamodal2" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="modallabel">Ubicación Hotel Cataratas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.5613229230457!2d-58.45098328521471!3d-34.589964864276716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5f0fd14568f%3A0xa13be2deb7ae0aab!2sAv.%20Corrientes%206365%2C%20Buenos%20Aires!5e0!3m2!1ses!2sar!4v1600214031270!5m2!1ses!2sar" width="468" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>            
                          </div>
                        </div>
                      </div>
                    </div>                  
                  </div> 

                  <div class="mb-2">
                    <h6 class=" atributohotel">Excelente ubicación</h6>
                    <h6 class=" atributohotel">Ideal familias</h6>
                    <h6 class=" atributohotel">Piscina climatizada</h6>
                  </div> 
                  
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab4" name="destino1" value="hab4">
                      <label for="hab4">Habitación Standar</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 0</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab5" name="destino1" value="hab5" >
                      <label for="hab5">Habitación Superior</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 180</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab6" name="destino1" value="hab6" >
                      <label for="hab6">Suite</label>
                    </div>
                    <div class="col-4"> 
                      <strong class="text-primary ">+ u$d 240</strong>
                    </div>  
                  </div>
                  
                  <img class="d-inline mb-0" src="images/trip.svg" height="12px" />
                  <a class="hab" href="https://www.tripadvisor.com.ar/" target="_blank">Ver en TripAdvisor</a>
                  <p class="d-inline"> | </p>
                  <a class="hab" href="https://www.tresortravel.com.ar/" target="_blank">Visitar web del hotel</a>
                </div>
              </div>
<!--final hotel-->   
   

            </div>
<!--final hoteles en un destino-->




            <hr/>


 <!--inicio hoteles en un destino-->
            <h4 class="panel-title mb-4">
              <a data-toggle="collapse" href="#collapse2">Hoteles en Salta<span class="icon-plus-circle iconomas mt-1 float-right"></a>
            </h4>
            <div id="collapse2" class="panel-collapse collapse">
             
				
				
              <div class="row form-group  ">               
                <div class="col-4 col-md-2 col-lg-4 col-xl-2 mb-3 mb-md-0">
                  <label class="mb-1 h5 mt-2" for="categoria2">Categoría</label>
                </div>
                <div class="col-8 col-md-4 col-lg-8 col-xl-4 mb-3 mb-md-0">
                  <select name="categoria2" class="form-control mb-3 ">
                    <option value="3est">3 estrellas</option>
                    <option value="4est">4 estrellas</option>
                    <option value="5est">5 estrellas</option>
                  </select>
                </div>
              
              </div>
				
				

<!--inicio hotel-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">

                  <!--inicio slider-->
                  <div id="carouselExampleIndicators3" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators3" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators3" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators3" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators3" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators3" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                

                </div>
                <div class="col-md-7  p-2 pl-3">
                  <h5 class=" d-inline ">Hotel Norte</h5>

                  <div class="mb-0 mt-0">
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />

                    <div class="ml-2 d-inline mt-0">         
                      <span class="icon-map-marker iconolugar mb-0 "></span>               
                      <a  class=" hab " href="#"  data-toggle="modal" data-target="#ventanamodal3">Ver mapa</a>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="ventanamodal3" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="modallabel">Ubicación Hotel Cataratas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.5613229230457!2d-58.45098328521471!3d-34.589964864276716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5f0fd14568f%3A0xa13be2deb7ae0aab!2sAv.%20Corrientes%206365%2C%20Buenos%20Aires!5e0!3m2!1ses!2sar!4v1600214031270!5m2!1ses!2sar" width="468" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>            
                          </div>
                        </div>
                      </div>
                    </div>                  
                  </div> 

                  <div class="mb-2">
                    <h6 class=" atributohotel">Excelente ubicación</h6>
                    <h6 class=" atributohotel">Ideal familias</h6>
                    <h6 class=" atributohotel">Piscina climatizada</h6>
                  </div> 
                  
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab1" name="destino2" value="hab1" checked>
                      <label for="hab1">Habitación Standar</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 0</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab2" name="destino2" value="hab2" >
                      <label for="hab2">Habitación Superior</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 180</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab3" name="destino2" value="hab3" >
                      <label for="hab3">Suite</label>
                    </div>
                    <div class="col-4"> 
                      <strong class="text-primary ">+ u$d 240</strong>
                    </div>  
                  </div>
                  
                  <img class="d-inline mb-0" src="images/trip.svg" height="12px" />
                  <a class="hab" href="https://www.tripadvisor.com.ar/" target="_blank">Ver en TripAdvisor</a>
                  <p class="d-inline"> | </p>
                  <a class="hab" href="https://www.tresortravel.com.ar/" target="_blank">Visitar web del hotel</a>
                </div>
              </div>
<!--final hotel-->   
   
   
<!--inicio hotel-->
              <div class="row form-group cuadrohotel rounded  ml-0 mr-0">
                <div class="col-md-5  p-0">

                  <!--inicio slider-->
                  <div id="carouselExampleIndicators4" class="carousel slide alto220" data-ride="carousel" data-interval="false">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators4" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators4" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators4" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner fondogris">
                      <div class="carousel-item active">
                        <img class="d-block alto220 mx-auto" src="images/hotel-011.jpg" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-022.jpg" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block alto220 mx-auto" src="images/hotel-033.jpg" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators4" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators4" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                  <!--fin slider-->                

                </div>
                <div class="col-md-7  p-2 pl-3">
                  <h5 class=" d-inline ">Hotel Salta</h5>

                  <div class="mb-0 mt-0">
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />
                    <img class="d-inline mb-1 " src="iconos/estrella.svg" height="14px" />

                    <div class="ml-2 d-inline mt-0">         
                      <span class="icon-map-marker iconolugar mb-0 "></span>               
                      <a  class=" hab " href="#"  data-toggle="modal" data-target="#ventanamodal4">Ver mapa</a>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="ventanamodal4" tabindex="-1" role="dialog" aria-labelledby="modallabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="modallabel">Ubicación Hotel Cataratas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          </div>
                          <div class="modal-body">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.5613229230457!2d-58.45098328521471!3d-34.589964864276716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5f0fd14568f%3A0xa13be2deb7ae0aab!2sAv.%20Corrientes%206365%2C%20Buenos%20Aires!5e0!3m2!1ses!2sar!4v1600214031270!5m2!1ses!2sar" width="468" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>            
                          </div>
                        </div>
                      </div>
                    </div>                  
                  </div> 

                  <div class="mb-2">
                    <h6 class=" atributohotel">Excelente ubicación</h6>
                    <h6 class=" atributohotel">Ideal familias</h6>
                    <h6 class=" atributohotel">Piscina climatizada</h6>
                  </div> 
                  
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab4" name="destino2" value="hab4">
                      <label for="hab4">Habitación Standar</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 0</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab5" name="destino2" value="hab5" >
                      <label for="hab5">Habitación Superior</label>
                    </div>
                    <div class="col-4">
                      <strong class="text-primary ">+ u$d 180</strong>
                    </div>  
                  </div>
                  <div class="row hab">
                    <div class="col-8">
                      <input type="radio" id="hab6" name="destino2" value="hab6" >
                      <label for="hab6">Suite</label>
                    </div>
                    <div class="col-4"> 
                      <strong class="text-primary ">+ u$d 240</strong>
                    </div>  
                  </div>
                  
                  <img class="d-inline mb-0" src="images/trip.svg" height="12px" />
                  <a class="hab" href="https://www.tripadvisor.com.ar/" target="_blank">Ver en TripAdvisor</a>
                  <p class="d-inline"> | </p>
                  <a class="hab" href="https://www.tresortravel.com.ar/" target="_blank">Visitar web del hotel</a>
                </div>
              </div>
<!--final hotel-->   
   

            </div>
<!--final hoteles en un destino-->


  
          </div>
                   
   
		  <div class="col-lg-4 p-4 ">
 			  
            <strong class="text-primary mb-4 mt-1 d-block precio">Resumen de la reserva</strong> 
			  			  
            <h3 class="font-weight-light mb-2">Cataratas del Iguazú</h3>
            <h5 class="font-weight-light mb-3">3 Noches</h5>
 
 
            <label class="text-black mb-1" for="hab">Fecha de viaje</label>
            <p class="m-0">Desde: 01/07/2020</p>
            <p class="mb-3">Hasta: 08/07/2020</p>
 

            <label class="text-black mb-0" for="hab">Servicios incluidos</label>
            <div class="mb-1">
              <img src="iconos/avion_n.svg" alt="Vuelo" width="30px" class="m-0 d-inline">
              <img src="iconos/bus_n.svg" alt="Traslado" width="30px" class="m-0 d-inline">
              <img src="iconos/hotel_n.svg" alt="Alojamiento" width="30px" class="m-0 d-inline">
              <img src="iconos/excursion_n.svg" alt="Excursiones" width="30px" class="m-0 d-inline">
              <img src="iconos/asistencia_n.svg" alt="Asistencia" width="30px" class="m-0 d-inline">
            </div>                 
            <ul class=" pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>3 noches de alojamiento en Iguazú con desayuno</li>
              <li>2 noches de alojamiento en Salta con desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  

            <div class="mb-3">
              <label class="text-black mb-0 d-block" >Hotel/es previsto/s:</label>
              <div>
                <p class=" d-inline m-0">Sheraton Cataratas</p>
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
              </div>
              <div>
                <p class=" d-inline m-0">Salta Resort & Spa</p>
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
                <img class="d-inline mb-1" src="iconos/estrella.svg" height="12px" />
              </div>
            </div>


            <label class="text-black mb-0" for="hab">Habitaciones</label>
            <div>
              <p class=" d-inline">- Habitación 1: 2 adultos y 2 menores</p>
            </div>
            <div>
              <p class=" d-inline">- Habitación 2: 4 adultos</p>
            </div>

 
            <label class="text-black mb-0 mt-3" for="hab">Viaja con bebés: Si</label>
     		  

            <hr/>

            <h5 class="mb-2 mt-4">Experiencias adicionales</h5>
            <p class="m-0">- Paseo en bici (3 pasajeros)</p>
            <p>- City Tour (2 pasajeros)</p>

          </div>	  
			  
			  
			  
          
        </div>
        
        </form>
        
        
      </div>
    </div>    
    
    
		

		
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h2>
 
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 1</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio <a href="experiencia.php" class=" d-inline subrayado">City Tour Panorámico</a> illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur <a href="experiencia.php" class="d-inline subrayado">Paseo en bici</a> adipisicing elit.</p>
                                
              </div>                
            </div>
            
            <hr>
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 2</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus <a href="experiencia.php" class=" d-inline subrayado">Visita a bodega Zucardi</a> alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>
            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 3</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>

              </div>                
            </div>

            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 4</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>


          </div>
          
          
          
        </div>
      </div>
    </div>    
		
		
		
		
		
		
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 
    
  </body>
</html>