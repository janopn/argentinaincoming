<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
			<h2 class="font-weight-light text-white mb-1" id="titulo">BA + Lagos y Glaciares</h2>
			<h5 class="font-weight-light text-white mb-2" >Buenos Aires, Bariloche, El Calafate y Ushuaia</h5>              
            <h5 class="font-weight-light text-white mb-1" id="noches">10 Noches</h5>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline" />
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline" />
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline" />
              <img src="iconos/excursion_b.svg" alt="Excursión" width="36px" class="m-0 d-inline" />
              <img src="iconos/barco_b.svg" alt="Nagegacion" width="36px" class="m-0 d-inline">
              <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline" />
            </div>                
 
 
 
            <ul class="text-white pl-3 datos">
              <li>Aéreos BA / Bariloche / Calafate / Ushuaia / BA</li>
              <li>Traslados de llegada y salida en cada destino</li>
              <li>3 noches con desayuno en Buenos Aires</li>
              <li>2 tours por Buenos Aires</li>
              <li>Cena Show de Tango</li>
              <li>3 noches con desayuno en Bariloche</li>
              <li>Navegación Isla Victoria y Bosque de Arrayanes</li>
              <li>Visita a los 7 lagos patagónicos y San Martín de los Andes</li>
              <li>2 noches con desayuno en Calafate</li>
              <li>Visita al Glaciar Perito Moreno</li>
              <li>2 noches con desayuno en Ushuaia</li>
              <li>Visita al Parque Nacional Tierra del Fuego + Tren Ecológico</li>
              <li>Navegación por el Canal de Beagle</li>                
            </ul>  
               
              
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/000601.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000102.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000106.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000107.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000108.jpg" alt="Image" class="img-fluid rounded" />
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>




    <div class="site-section">
      <div class="container">

        <form action="consultaprograma.php" class=" bg-light">

			
		  <div class="row bg-light">
			  			  	  			  
                <div class="col-12 col-md-9 mt-4 pl-3">
	    			<h3 class="font-weight-light azul">¡Reservá tu programa!</h3>
					<h6 class="mb-2" >Seleccioná la opción de tu preferencia y consultanos</h6>			
                </div>
                <!--
				<div class="col-12 col-md-3 mt-4  ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			    -->
   
		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  

          <!-- -->			  
		  <div class="row bg-light pb-3 mb-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha1">Septiembre a Diciembre</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel1">Hoteles 4*</label>
	        </div>		

		    <div class="col-lg-6 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(1, 'DBL');" checked></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1DBL">u$d 1270</strong>
	    		  <strong class="text-primary legal d-block" id="base1">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		
			
          </div>
		  <!-- -->
        
        
        
<!--        
        
		  <div class="row bg-light">		  
            <div class="col-12 mt-2 mb3">
				<strong class="text-primary legal d-block mb-3">Tarifas válidas hasta el 31/10/2022</strong>								
            </div>
		  </div>	
        
    -->    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="submit" value="Continuar" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        
		  
          
        </form>
          
          
      </div>
    </div>    
	

	  
	  
		
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-2">Itinerario</h3>
 
            <div class="text-center">  
              <img class="responsive max300" src="images/itinerario0006.jpg" />  
            </div>    
              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 1</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Bienvenida y traslado desde el aeropuerto al hotel en Buenos Aires.
Por la tarde, realizaremos nuestro tour Buenos Aires al Norte, conociendo los barrios de Recoleta y Palermo, Cementerio de la Recoleta, Floralis Genérica y los lagos de Palermo con su Rosedal.
Por la noche, disfrutarás de una exquisita cena y un Show de Tango auténtico porteño.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 2</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Por la mañana, realizaremos nuestro tour Buenos Aires al Sur, que te permitirá conocer el Casco Histórico de la ciudad, los barrios de La Boca, San Telmo y Montserrat, finalizando el tour al mediodía en Puerto Madero dónde podrás almorzar.
Te aconsejamos añadir nuestra experiencia Postales de Buenos Aires, una navegación con las mejores vistas de la ciudad desde el Río de la Plata.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 3</h5>
                <h6 class="mb-2">Buenos Aires - Bariloche</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto de Buenos Aires para tomar su vuelo a Bariloche. Traslado al hotel en Bariloche. Por la tarde, visita por el Circuito Chico, uno de los paseos más tradicionales para disfrutar de las maravillas del paisaje.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 4</h5>
                <h6 class="mb-2">Bariloche</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Por la mañana, visita por el Circuito Chico, uno de los paseos más tradicionales para disfrutar de las maravillas del paisaje y la historia de la ciudad de Bariloche.
Por la tarde, realizaremos una navegación a la Isla Victoria y el Bosque de Arrayanes, donde podrás conocer la flora autóctona de la región y caminar por senderos que te llevarán a descubrir pinturas rupestres hechas por pueblos originarios de esta zona.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 5</h5>
                <h6 class="mb-2">Bariloche</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Visitaremos San Martín de los Andes recorriendo los 7 lagos: Espejo, Correntoso, Escondido, Villarino, Falkner, Machónico, y Lácar, a orillas del cual está emplazada la magnífica ciudad de San Martín de los Andes donde podrás almorzar.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 6</h5>
                <h6 class="mb-2">Bariloche - El Calafate</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto de Bariloche para tomar su vuelo a El Calafate con escala en Buenos Aires. Traslado al hotel y tiempo libre en El Calafate.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 7</h5>
                <h6 class="mb-2">El Calafate</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Visitaremos el Parque Nacional Los Glaciares donde se encuentra el Glaciar Perito Moreno, Patrimonio de la Humanidad. Día completo. Podrás almorzar dentro del Parque Nacional.<br/><br/> Experiencias sugeridas para disfrutar más de cerca el glaciar:<br/> -Safari Náutico<br/> -Minitrekking sobre el Glaciar</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h6 class="mb-2 azul">Día adicional en Calafate</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Si extiendes tu estadía en este destino, te recomendamos estas experiencias:<br/><br/> -El Chaltén con Almuerzo<br/> -Torres del Paine 4x4 con almuerzo<br/> -Día de Campo en Estancia Nibepo Aike con Cabalgata</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 8</h5>
                <h6 class="mb-2">El Calafate - Ushuaia</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto de El Calafate para tomar su vuelo a Ushuaia. Traslado al hotel y tarde libre para recorrer la ciudad de Ushuaia.<br/><br/>Sugerimos nuestra experiencia de noche:<br/>-Nieve y Fuego, perros Huskies y Raquetas</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 9</h5>
                <h6 class="mb-2">Ushuaia</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Visitaremos el Parque Nacional Tierra del Fuego donde disfrutarás la mágica experiencia de viajar en el Tren del Fin del Mundo a través de increíbles paisajes, compuestos por ríos, cascadas y el majestuoso bosque. Por la tarde, realizaremos una navegación por el Canal de Beagle con vista panorámica de la costa de Ushuaia, observando la isla de los lobos marinos y la isla de los pájaros Cormoranes Magallánicos e Imperiales, culminando el paseo con el Faro Les Eclaireurs, el mítico faro patagónico.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h6 class="mb-2 azul">Día adicional en Ushuaia</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Si extiendes tu estadía en este destino, incluimos esta experiencia:<br/> -Lagos Off Road</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 10</h5>
                <h6 class="mb-2">Ushuaia - Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto de Ushuaia para tomar su vuelo de regreso a Buenos Aires. Traslado al hotel y tarde libre en Buenos Aires.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h6 class="mb-2 azul">Día adicional en Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Si extiendes tu estadía en este destino, te recomendamos estas experiencias:<br/> -San Antonio de Areco (Campo & Tradición)<br/> -Full Day Delta Tigre</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 11</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto para tomar su vuelo de regreso.</p>
              </div>                
            </div>

              
              
              
              
              
              
              
              
              

          </div>
          
          
          
        </div>
      </div>
    </div>    
		
		
		
		
		
		
		
		
		
		
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios"  />
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
  <?php include 'scriptsprogramas.html';?>

 

    
  </body>
</html>