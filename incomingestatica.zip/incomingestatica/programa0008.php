<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
			<h2 class="font-weight-light text-white mb-1" id="titulo">Perlas de Sudamérica</h2>
			<h5 class="font-weight-light text-white mb-2" >Buenos Aires, Cusco, Machu Picchu, Lima y Río de Janeiro</h5>      
            <h5 class="font-weight-light text-white mb-1" id="noches">14 Noches</h5>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline" />
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline" />
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline" />
              <img src="iconos/excursion_b.svg" alt="Excursión" width="36px" class="m-0 d-inline" />
            </div>                
 
 
 
            <ul class="text-white pl-3 datos">
                <li>Vuelos internos (BUE/CUS/LIM/RIO)</li>
              <li>Traslados de llegada y salida</li>
              <li>4 noches de alojamiento con desayuno en Buenos Aires </li>
              <li>City Tour en Buenos Aires</li>
              <li>Excursión full day a Tigre con navegación por el Delta </li>
              <li>Visita a Estancia con Almuerzo</li>
              <li>Show de Tango</li>
              <li>3 noches de alojamiento con desayuno en Cusco</li>
              <li>City tour en Cusco</li>
              <li>Tickets de tren</li>
              <li>1 noche de alojamiento con desayuno en Aguas Calientes </li>
              <li>Entrada a Machu Picchu</li>
              <li>1 noche de alojamiento con desayuno en Lima</li>
              <li>5 noches de alojamiento con desayuno en Río de Janeiro </li>
              <li>City tour en Río de Janeiro</li>
              <li>Visita al Cristo Redentor y Pan de Azúcar</li>
            </ul>  
           
              
              
              
              
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/000801.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000802.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000803.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/000804.jpg" alt="Image" class="img-fluid rounded" />
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>




    <div class="site-section">
      <div class="container">

        <form action="consultaprograma.php" class=" bg-light">

			
		  <div class="row bg-light">
			  			  	  			  
                <div class="col-12 col-md-9 mt-4 pl-3">
	    			<h3 class="font-weight-light azul">¡Reservá tu programa!</h3>
					<h6 class="mb-2" >Seleccioná la opción de tu preferencia y consultanos</h6>			
                </div>
                <!--
				<div class="col-12 col-md-3 mt-4  ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			    -->
   
		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  

          <!-- -->			  
		  <div class="row bg-light pb-3 mb-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha1">Septiembre a Diciembre</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel1">Hoteles según programa</label>
	        </div>		

		    <div class="col-lg-6 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(1, 'DBL');" checked></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1DBL">u$d 4500</strong>
	    		  <strong class="text-primary legal d-block" id="base1">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		
			
          </div>
		  <!-- -->
        
        
        
 <!--       
        
		  <div class="row bg-light">		  
            <div class="col-12 mt-2 mb3">
				<strong class="text-primary legal d-block mb-3">Tarifas válidas hasta el 31/10/2022</strong>								
            </div>
		  </div>	
     -->   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="submit" value="Continuar" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        
		  
          
        </form>
          
          
      </div>
    </div>    
	

	  
	  
		
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-2">Itinerario</h3>
 <!--
            <div class="text-center">  
              <img class="responsive max300" src="images/itinerario0008.jpg" />  
            </div>    
       -->       
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 1</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Bienvenida y traslado desde el aeropuerto al hotel en Buenos Aires. Resto del día libre para disfrutar la ciudad.
Por la noche, disfrutarás de una exquisita cena y un Show de Tango auténtico porteño.
</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 2</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>City Tour
Comenzaremos por la mañana conociendo los orígenes de la ciudad, las zonas más antiguas, el colorido barrio de La Boca lleno de influencia inmigratoria y arte bohemio, descubriendo la pasión por el fútbol argentino.
Luego nos dirigiremos hacia San Telmo, el más barrio antiguo de Buenos Aires, con sus históricas calles, túneles y misterio, visitaremos el antiguo mercado, las mejores tiendas de antigüedades, plateros famosos, joyeros locales y arte colonial.
Al mediodía visitaremos el barrio más moderno de la ciudad, Puerto Madero, con su elegante Puente de la Mujer donde disfrutaremos de un almuerzo con vista a los famoso diques.
Después del almuerzo iremos a Plaza de Mayo, el corazón de la ciudad, llena de historia y arquitectura, donde se encuentra la Casa Rosada, la Catedral Metropolitana y el Cabildo.
Dejando atrás el Casco Histórico, nos dirigiremos a Recoleta, donde sus edificios tanto los palaciegos como los modernos, son dignos de admiración. Se destacan allí también la
Floralis Genérica, la Facultad de Derecho y el Cementerio, uno de los tres más reconocidos del mundo, donde descansan los restos de Evita y las personalidades argentinas más icónicas.
Terminaremos el tour en Palermo, donde disfrutarás de sus parques, plazas y lagos, uno de los espacios verdes más grandes e importantes de Buenos Aires junto con el Planetario Galileo Galilei y su hermoso rosedal.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 3</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Excursión full day a Tigre c/ navegación por el Delta
Iniciaremos la excursión en la estación fluvial Sturla en Puerto Madero. Una vez que arribamos a la ciudad de Tigre, partiremos en una embarcación confortable desde la estación fluvial para navegar cinco de los principales ríos de la primera sección del Delta, con audioguía y refrigerio a bordo. Navegaremos durante una hora por los ríos Luján, Carapachay, Angostura, Espera y Sarmiento.
Luego podrás disfrutar de un almuerzo gourmet en un destacado restaurante Kanoo ubicado en una de las Islas del Delta.
Al volver a la zona continental, realizaremos un city tour por la ciudad de Tigre, que te permitirá conocer sus principales atractivos, entre los que se destacan el Puerto de Frutos, Museo de Arte de Tigre y el Paseo Victorica.</p>
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 4</h5>
                <h6 class="mb-2">Buenos Aires</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Visita a Estancia La Candelaria con Almuerzo
Conectate con la naturaleza, respira aire puro y conocé la tradición del campo argentino. Disfrutá los servicios y actividades de la Estancia, show folclórico, charla histórica en el Castillo, clase de empanadas argentinas y mucho más.
Comidas incluidas: recepción, plato principal, postre y 1 bebida sin alcohol por persona y té de la tarde.</p>
              </div>                
            </div>
            
            <hr />
               
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 5</h5>
                <h6 class="mb-2">Buenos Aires - Cusco</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto en Bs As. Vuelo a Lima. Traslado al hotel en Cusco. Resto del día libre.</p>
              </div>                
            </div>
            
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 6</h5>
                <h6 class="mb-2">Cusco</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>City tour.
Nuestro encuentro será en la Plaza de Armas de Cusco y el recorrido empieza con la visita a la fortaleza de Sacsayhuamán, una de las construcciones más emblemáticas de los incas desde donde podrá apreciar una vista privilegiada de casi toda la ciudad.
Siga rumbo a Qenqo, un complejo arqueológico de uso principalmente ceremonial – astronómico.
Luego, conozca Pukapukara, que fue una fortaleza de uso militar con múltiples ambientes, plazas, baños, acueductos, muros y torres.
Finalmente, visitaremos Tambomachay, recinto arqueológico con canales de agua hechos en piedra labrada que posiblemente era dedicado a la adoración del agua. 18:00 aprox: llegamos al centro histórico de Cusco y así culminamos el City Tour 4 ruinas Cusco.</p>
              </div>                
            </div>
            
            <hr />
               
                                  
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 7</h5>
                <h6 class="mb-2">Cusco - Aguas Calientes</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Inicio: A las 6:30 am nos reuniremos en la Plaza de Armas de Cusco para abordar la movilidad turística.
Final: A las 7pm en la Plaza San Francisco.
Lugares a visitar:
Chinchero: Uno de los pocos sitios en donde parece que el tiempo no pasa, ya que las tradiciones y la cultura inca aún persiste.
Moray: Misterioso sitio arqueológico inca compuesto por andenes en forma de anfiteatro de experimentación agrícola.
Maras: Impresionantes pozos de sal donde se observa mas de 5,000 pozos y que son explotados desde el periodo de los incas.
Urubamba: Tendremos el almuerzo buffet (Opcional a cuenta del pasajero).
Ollantaytambo: habitado ininterrumpidamente desde tiempos Inca, y suba por la icónica fortaleza, construida al lado de la montaña.
07:00 pm: Abordaremos el tren con destino al pueblo de aguas calientes, llegando a las 8:50 pm, donde un representante del Hotel lo estará esperando en la Plaza de Aguas Calientes o Machu Picchu Pueblo para darle la bienvenida y acompañarlo.
Noche de hotel y la charla con el guía para coordinar su visita del día siguiente (Machu Picchu).</p>
              </div>                
            </div>
            
            <hr />
               
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 8</h5>
                <h6 class="mb-2">Machu Picchu - Cusco</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Nuestra hora de ingreso a Machu Picchu estará programada para las 10:00 am aproximadamente.
Tendrán una visita guiada por 2 horas, realizando el recorrido por los puntos principales como: la plaza principal, sector urbano, la torre circular, el reloj solar, el cementerio inca, etc.
A la hora acordada estaremos de regreso al pueblo de Aguas Calientes – Machu Picchu, disfruta de tiempo libre para almorzar y explorar Aguas Calientes.
Como BONUS al tour, visita el Nuevo circuito de “CRÓNICAS DE PIEDRA” vivencias talladas en 37 rocas que representan la cosmovisión andina del pueblo de AGUAS CALIENTES.
A la hora acordada abordaremos el tren de Aguas Calientes hacia el pueblo de Ollantaytambo.
Nuestro Transfer será el encargado de embarcarlos con dirección a su hotel en la Ciudad de Cusco en una minivan.</p>
              </div>                
            </div>

    
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 9</h5>
                <h6 class="mb-2">Cusco - Lima</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto de Cusco. Vuelo a Lima. Traslado al hotel.
City tour en Lima.</p>
              </div>                
            </div>
              
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 10</h5>
                <h6 class="mb-2">Lima - Río de Janeiro</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto en Lima. Vuelo a Río de Janeiro. Traslado al hotel.
</p>
              </div>                
            </div>
              
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 11</h5>
                <h6 class="mb-2">Río de Janeiro</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>City Tour: El Monte Pan de Azúcar y Corcovado
El tour comienza con el pick up en su hotel para visitar la colina del Corcovado y la estatua del Cristo Redentor, situada a 710 metros de altura. Es uno de los lugares más visitados de la ciudad, y también es un tour ecológico, ya que subimos el cerro Corcovado en una camioneta, dentro del Parque Nacional del Bosque de Tijuca, el bosque urbano más grande del mundo.
Desde la cima de la colina, podemos ver la Laguna Rodrigo de Freitas, en el norte de la ciudad y varias playas. Después de contemplar la maravillosa vista panorámica de la ciudad, procederemos al legendario Estadio Maracanã, donde nos detendremos para que pueda visitar el Museo Maracanã (opcional). Luego, iremos a la famosa Avenida do Carnaval, Sambódromo, con acceso al Museo de la Samba y entrada a la Plaza Apoteose.
Después de almorzar en una Churrasquería tradicional, visitaremos el cerro Pan de Azúcar, situado a 395 metros sobre el nivel del mar, en medio de la Bahía de Guanabara. La subida se realiza por un teleférico de cristal hasta la cima de la montaña, desde donde se puede disfrutar de una maravillosa vista de 360° de la Bahía de Guanabara, Copacabana, Urca, Botafogo, Flamengo y sus alrededores. Antes de terminar el recorrido, pasaremos por el Centro Histórico de la ciudad con paradas en la Catedral Metropolitana y en la Escalera de Selarón y pasando por los famosos Arcos de la Lapa. Luego de un día lleno de cultura, volveremos al hotel para descansar.</p>
              </div>                
            </div>
              
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Días 12, 13 y 14</h5>
                <h6 class="mb-2">Río de Janeiro</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Días libres para explorar la ciudad y sus playas. Actividades sugeridas:
-Paseo en jeep por el bosque tropical y el jardín botánico de Tijuca. -Tour privado a Arraial Do Cabo
</p>
              </div>                
            </div>
              
            <hr />
                              
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-0">Día 15</h5>
                <h6 class="mb-2">Río de Janeiro</h6>                  
              </div>               
              <div class="col-12 col-md-10">
                <p>Traslado al aeropuerto para tomar el vuelo de regreso.</p>
              </div>                
            </div>

          </div>
          
          
          
        </div>
      </div>
    </div>    
		
		
		
		
		
		
		
		
		
		
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios"  />
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
  <?php include 'scriptsprogramas.html';?>

 

    
  </body>
</html>