<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">Cataratas del Iguazú</h2>
            <h5 class="font-weight-light text-white mb-1">3 Noches</h2>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline">
              <img src="iconos/excursion_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline">
            </div>                
 
 
 
            <ul class="text-white pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>Alojamiento en el Hotel Cataratas Resort con régimen de desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  
 
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slideriguazu.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/sliderbariloche.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>
	  
	  
	  
	  
  
    
    <div class="site-section">
      <div class="container">
		  <div class="row bg-light">			  			  			  
            <div class="col py-5">	
	    	  <h3 class="font-weight-light azul d-inline">¡Tu reserva ha sido realizada con éxito! Nos comunicaremos con vos a la brevedad</h3>
			</div>
		  </div>	
		</div>	
    </div>    
	  
	  
	  
	  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h2>
 
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 1</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio <a href="experiencia.php" class=" d-inline subrayado">City Tour Panorámico</a> illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur <a href="experiencia.php" class="d-inline subrayado">Paseo en bici</a> adipisicing elit.</p>
                                
              </div>                
            </div>
            
            <hr>
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 2</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus <a href="experiencia.php" class=" d-inline subrayado">Visita a bodega Zucardi</a> alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>
            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 3</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>

              </div>                
            </div>

            
            <hr>

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 4</h2>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>


          </div>
          
          
          
        </div>
      </div>
    </div>    

	  
	  
	  
	  
	  
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>