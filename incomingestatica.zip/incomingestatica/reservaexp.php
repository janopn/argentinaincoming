<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   

  
	  
	  
	  <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">City Tour Panorámico</h2>
            <h5 class="font-weight-light text-white mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
  
  
            <div class="mb-3">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/barco_b.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
              <img src="iconos/bici_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/comida_b.svg" alt="Comida" width="36px" class="m-0 d-inline">
            </div>                
  
  
 
            <ul class="text-white pl-3 mb-4">
              <li>Bus turistico</li>
              <li>4 descensos</li>
              <li>Almuerzo (sin bebidas)</li>
            </ul>  
 
            
            <p class="font-weight-light text-white mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
            <p class="font-weight-light text-white mb-0"><strong>Duración:</strong> 8 hs.</p>            
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
 
			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  



          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slidercaminito.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/slidermapa.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>
	  
	  
	  
	  
	  
  
    
    <div class="site-section">
      <div class="container">

        <form action="reservaexpok.php" class="">

		  
		  <div class="row bg-light">
			  			  
            <div class="col-lg-3 border-right mt-4 pt-3 pl-4">
              <strong class="text-primary mb-1 d-block precio">Total reserva:</strong> 
              <strong class="text-primary preciodestacado d-block mb-1">u$d 380</strong>
              <strong class="text-primary legal d-block ">Tarifa total por 4 pasajeros</strong>
			</div>
			  
			  
            <div class="col-lg-9 ">
			
    		  <div class="row bg-light ">
			  			  
                <div class="col-md-12 mt-4 ml-2">
	    			<h3 class="font-weight-light azul">¡Finalizá tu reserva!</h3>
					<h6 class="mb-2" >Completá tus datos y listo</h6>			
                </div>
    		  </div>	  			 
			  
			
    		  <div class="row bg-light ">			  
                <div class="col-12 col-lg-6 mt-3 px-4">
    	  	      <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">Paso 2 de 2</div>
                  </div>				
    			</div>

				<div class="col-6 col-lg-3 mt-1 pl-4 ">  
                    <input type="submit" value="Volver" class="btn btn-primary text-white rounded ancho ">
    			</div> 		 
				  
				<div class="col-6 col-lg-3 mt-1 pr-4 ">  
                    <input type="submit" value="¡Reservar!" class="btn btn-primary text-white rounded ancho">
    			</div> 		 
			  
    		  </div>	
			</div>

		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr>								
            </div>
		  </div>	
		  
		  
		  
		  

        <div class="row bg-light">

          
          
          
          
          <div class="col-lg-7 mb-5 p-4 border-right">

           
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">Nombre</label>
                  <input type="text" id="fname" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Apellido</label>
                  <input type="text" id="lname" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="email">E-Mail</label> 
                  <input type="email" id="email" class="form-control">
                </div>
                <div class="col-md-6 ">
                  <label class="text-black" for="ltel">Teléfono</label> 
                  <input type="text" id="ltel" class="form-control">
                </div>
                                
              </div>



              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="message">Comentarios</label> 
                  <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="Contanos que expectativas tenés de tu experiencia o cualquier cosa que quieras agregar."></textarea>
                </div>
              </div>


				
       		  <!-- IMPORTANTE: ESTA LEYENDA ES CONDICIONAL, PONERLA SOLAMENTE CUANTO SE HA SELECCIONADO EL CHECKBOX "VIAJO CON BEBÉ/S" -->	
              <div class="row form-group">
                <div class="col-md-12">
                  <p class=""><strong>Importante:</strong> Los costos de los infantes serán notificados por un agente de viajes de la empresa.</p> 
                </div>
              </div>
				
				
  
          </div>
                   
   
		  <div class="col-lg-5 p-4 ">
 			  
            <strong class="text-primary mb-4 mt-1 d-block precio">Resumen de la reserva</strong> 
			  			  
            <h2 class="font-weight-light mb-2">City Tour</h2>
 
            <p class=" mb-0">Fecha: 01/07/2020</p>
            <p class=" mb-0">Cantidad: 2 adultos y 2 menores</p>
            <p class=" mb-3">Viaja con bebés: Si</p>
 
          </div>	  
			  
			  
			  
          
        </div>
        
        </form>
        
        
      </div>
    </div>  
	  
	  
	  
	  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
 
            <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
            </p>
            
          </div>
         
        </div>
      </div>
    </div>    
	  
	  
	  
	  
	  
	  
	  
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>