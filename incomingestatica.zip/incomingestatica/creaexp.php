<!DOCTYPE html>
<html lang="en">
<?php include 'head.html'; ?>
  <body>
    <?php include 'menu.html';?>
    <?php include 'incompleteMandatoryFields.html'; ?>
    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/slidermapa.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h1 class="text-white font-weight-normal">Creá tu experiencia</h1>
            </div>
          </div>
        </div>
      </div>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-12 text-center">
            <h3 class="font-weight-light text-black">Completá el formulario y te ofreceremos una experiencia a medida</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-12 mb-5">
            <form action="thanks.php" method="post" name="Form" class="p-5 bg-white" onsubmit="return processForm();">
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">Nombre</label>
                  <input type="text" id="fname" name="fname" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Apellido</label>
                  <input type="text" id="lname" name="lname" class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="email">E-Mail</label> 
                  <input type="email" id="email" name="email" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lpais">Idioma</label>
                  <input type="text" id="lpais" name="lpais" class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-6 col-lg-4 mb-3 mb-lg-0  ">
                  <label class="text-black" for="fcant">Cantidad de pasajeros</label>
                  <input type="number" id="fcant" name="fcant" class="form-control" min="1" max="100">
                </div>
                <div class="col-md-6 col-lg-4 mb-3 mb-lg-0 ">
                  <label class="text-black" for="fedades">Edades</label>
                  <input type="text" id="fedades" name="fedades" class="form-control">
                </div>
                <div class="col-md-6 col-lg-4  ">   
                  <label class="text-black b" for="lacomp">¿Incluir vuelos internacionales?</label>
                  <label class="radio mr-3 mt-2">
                    <input class="mr-1" type="radio" name="optradio" id="lacomp" value="Si">Si
                  </label>
                  <label class="radio">
                    <input class="mr-1" type="radio" name="optradio" id="lacomp" value="No" checked>No
                  </label>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-lg-3 col-md-6 mb-3 mb-lg-0">
                  <label class="text-black" for="fdesde">Desde</label> 
                  <input type="text" name="fdesde" class="form-control datepicker px-2" placeholder="Desde">
                </div>
                <div class="col-lg-3 col-md-6 mb-3 mb-lg-0">
                  <label class="text-black" for="fhasta">Hasta</label> 
                  <input type="text" name="fhasta" class="form-control datepicker px-2" placeholder="Hasta">
                </div>
                <div class="col-md-6 col-lg-3 mb-3 mb-md-0  ">
                  <label class="text-black" for="fdias">Cantidad de días</label>
                  <input type="number" id="fdias" name="fdias" class="form-control" min="1" max="21">
                </div>
                <div class="col-md-6 col-lg-3  ">   
                  <label class="text-black b" for="lflex">Flexibilidad de fechas</label>
                  <label class="radio mr-3 mt-2">
                    <input class="mr-1" type="radio" name="flexradio" id="lflex" value="Si" checked>Si
                  </label>
                  <label class="radio">
                    <input class="mr-1" type="radio" name="flexradio" id="lflex" value="No">No
                  </label>
                </div>
              </div>
              <div class="row form-group">
              <div class="col-12 mt-4">
                <label class="text-black b" >¿Que destinos te interesa conocer?</label>
              </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest1">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Buenos Aires">Buenos Aires
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest2">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Iguazú">Iguazú
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest3">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Salta">Salta
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest4">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Jujuy">Jujuy
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest5">
                    <input class="mr-2" type="checkbox" name="destino[]" value="San Juan">San Juan
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest6">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Mendoza">Mendoza
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest7">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Bariloche">Bariloche
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest8">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Puerto Madryn">Puerto Madryn
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest9">
                    <input class="mr-2" type="checkbox" name="destino[]" value="El Calafate">El Calafate
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest10">
                    <input class="mr-2" type="checkbox" name="destino[]" value="El Chaltén">El Chaltén
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="dest11">
                    <input class="mr-2" type="checkbox" name="destino[]" value="Ushuaia">Ushuaia
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                    <input class="form-control alto30" type="text" name="otroDestino" value="" placeholder="Otros destinos...">
                </div>
              </div>
              <div class="row form-group">
              <div class="col-12 mt-2">
                <label class="text-black b" >¿Que tipo de experiencias te gustaría vivir?</label>
              </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp1">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Cultural">Cultural
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp2">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Aventura">Aventura
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp3">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Gastronómica">Gastronómica
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp4">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Ski">Ski
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp5">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Trekking">Trekking
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="exp6">
                    <input class="mr-2" type="checkbox" name="experiencia[]" value="Lujo">Lujo
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                    <input class="form-control alto30" type="text" name="otraExperiencia" value="" placeholder="Otras experiencias...">
                </div>
              </div>
              <div class="row form-group">
              <div class="col-12 mt-2">
                <label class="text-black b" >¿Que servicios querés incluir?</label>
              </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="ser1">
                    <input class="mr-2" type="checkbox" name="servicio[]" value="Vuelos locales" checked>Vuelos locales
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="ser2">
                    <input class="mr-2" type="checkbox" name="servicio[]" value="Traslados" checked>Traslados
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="ser3">
                    <input class="mr-2" type="checkbox" name="servicio[]" value="Alojamiento" checked>Alojamiento
                  </label>
                  <select name="categoria" class="form-control-cat">
                    <option value="3 estrellas">3 estrellas</option>
                    <option value="4 estrellas">4 estrellas</option>
                    <option value="5 estrellas">5 estrellas</option>
                  </select>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="ser4">
                    <input class="mr-2" type="checkbox" name="servicio[]" value="Excursiones/Experiencias" checked>Excursiones/Experiencias
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                  <label class="checkbox-inline" for="ser5">
                    <input class="mr-2" type="checkbox" name="servicio[]" value="Vehículo">Vehículo
                  </label>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3">
                    <input class="form-control alto30" type="text" name="otroServicio" value="" placeholder="Otros servicios...">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12 mt-1">
                  <label class="text-black" for="message">Comentarios</label>
                  <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="¿Que soñas experimentar en este viaje?"></textarea>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12 mt-2">
                 <label class="checkbox-inline" for="news">
                    <input class="mr-2" type="checkbox" name="news" value="Si" checked>¡Recibir newsletters con las mejores promos!
                  </label>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12 mt-2">
                  <div class="g-recaptcha" data-sitekey="6LcXqZEgAAAAADRZaOX7dYjZ2HSFwMJq_ZU6iNuV"></div>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                <input type="hidden" id="hdnsource" name="hdnsource" value="creaexp">
                  <input type="submit" value="Enviar" class="btn btn-primary py-2 px-4 text-white rounded">
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php include 'footer.html';?>
  </div>
  <?php include 'scripts.html';?>
  </body>
  <script src="validate.js"></script>
  <script type="text/javascript">
    function processForm() {
      fnameValidation = validateField("fname");
      emailValidation = validateField("email");
      recaptchaValidation = grecaptcha.getResponse() != "";

      isValid = fnameValidation && emailValidation && recaptchaValidation;

      if(!isValid){
        $('#myModal').modal();
      }

      return isValid;
    }
  </script>
</html>