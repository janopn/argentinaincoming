<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2" id="titulo">Arte urbano - Circuito Palermo</h2>
                
              
  
            <div class="mb-3">
              <img src="iconos/excursion_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
            </div>                
    
 
            <ul class="text-white pl-3 mb-4">
              <li>Guía</li>
            </ul>  
               
              
              
            <p class="font-weight-light text-white mb-0"><strong>Salidas:</strong> Todos los días</p>            
            <p class="font-weight-light text-white mb-0"><strong>Horarios de partida:</strong> 10  y 15 hs.</p>   
            <p class="font-weight-light text-white mb-0"><strong>Duración:</strong> 2 hs.</p>   
            <p class="font-weight-light text-white mb-0"><strong>Punto de partida:</strong> Plaza Mafalda</p>   
            <p class="font-weight-light text-white mb-0"><strong>Consultar por pick-up y drop-off por hotel </strong></p>   

            </br> 
              
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
 
    
             
			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a> 
			</div>  			  



          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/e161201.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/e161202.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>


	  

      
    <div class="site-section">
      <div class="container">

        <form action="consultaprograma.php" class=" bg-light">

			
		  <div class="row bg-light">
			  			  	  			  
                <div class="col-12 col-md-9 mt-4 pl-3">
	    			<h3 class="font-weight-light azul">¡Reservá tu experiencia!</h3>
					<h6 class="mb-2" >Seleccioná la opción de tu preferencia y consultanos</h6>			
                </div>
                <!--
				<div class="col-12 col-md-3 mt-4  ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			    -->
   
		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  
          <!-- -->			  
		  <div class="row bg-light pb-3 mb-0">
              
            <div class="col-lg-6 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha1">Septiembre a Diciembre</label>		  
		    </div>	  			  
		    <div class="col-lg-6 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButtonExp(1);" checked></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1">u$d 20</strong>
	    		  <strong class="text-primary legal d-block" id="base1">Por persona (mínimo 2 personas)</strong> 	
                </div>
              </div>    
			</div>		

			
          </div>
		  <!-- -->
        
 
        
        

<!--
        
        
		  <div class="row bg-light">		  
            <div class="col-12 mt-2 mb3">
				<strong class="text-primary legal d-block mb-3">Tarifas válidas hasta el 31/12/2022</strong>								
            </div>
		  </div>	
        
       
        
     -->   
        
        
        
        
        
        
        
        
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="submit" value="Continuar" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        
		  
          
        </form>
          
          
      </div>
    </div>    
      
      
      
      
      
      
	  	  
	  
	  
	  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
              
            <p>Una mirada diferente de esta ciudad maravillosa a través de una experiencia visual única y sumamente interesante, que te permite conocer este barrio de Buenos Aires a través del arte.</p>

            <p>Recorreremos las calles del barrio de Palermo en busca de intervenciones de artistas urbanos tales como, grafitis, pegatinas y murales.</p>
                
            <p>Durante la última década Buenos Aires se volvió uno de los epicentros del arte urbano más importantes de la región.</p> 
                
            <p>Por medio de estos diversos lenguajes nos sumergiremos en un mundo donde el arte de denuncia política y social están en su máximo esplendor. Esta experiencia te permitirá conocer Buenos Aires desde la ventana del arte urbano.</p>
                         
              
          </div>
         
        </div>
      </div>
    </div>    
	  
	 
    
	  
	  
	  
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
  <?php include 'scriptsexperiencias.html';?>

 

    
  </body>
</html>