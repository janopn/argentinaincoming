<!DOCTYPE html>
<html lang="en">
<?php include 'head.html';?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '/home/mike/vendor/autoload.php';

$body = "";
$subject = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(valueOrEmpty('hdnsource')=="consultaprograma"){
        $email = valueOrEmpty('email');
        $fname = valueOrEmpty('fname');
        $lname = valueOrEmpty('lname');
        $fecha = valueOrEmpty('fechad');
        $cantidad = valueOrEmpty('cant');
        $telefono = valueOrEmpty('ltel');
        $mensaje = valueOrEmpty('message');
        $titulo = valueOrEmpty('hdntitulo');
        $noches = valueOrEmpty('hdnnoches');
        $rangofechas = valueOrEmpty('hdnrangofecha');
        $hotel = valueOrEmpty('hdnhotel');
        $precio = valueOrEmpty('hdnprecio');
        $base = valueOrEmpty('hdnbase');

        $body = "";
        $body = $body."<strong>Info pasajero</strong><br/>";
        $body = $body."Email: ".$email."<br/>";
        $body = $body."Nombre: ".$fname." ".$lname."<br/>";
        $body = $body."Fecha: ".$fecha."<br/>";
        $body = $body."Cantidad: ".$cantidad."<br/>";
        $body = $body."Telefono: ".$telefono."<br/>";
        $body = $body."Mensaje: ".$mensaje."<br/>";
        $body = $body."<br/>";
        $body = $body."<strong>Info programa</strong><br/>";
        $body = $body."Titulo: ".$titulo."<br/>";
        $body = $body."Noches: ".$noches."<br/>";
        $body = $body."Rango Fechas: ".$rangofechas."<br/>";
        $body = $body."Hotel: ".$hotel."<br/>";
        $body = $body."Precio: ".$precio."<br/>";
        $body = $body."Base: ".$base."<br/>";

        $subject = "Consulta Web - Argentina Incoming";
    }

    if(valueOrEmpty('hdnsource')=="contacto"){
        $email = valueOrEmpty('email');
        $fname = valueOrEmpty('fname');
        $lname = valueOrEmpty('lname');
        $cantidad = valueOrEmpty('cant');
        $telefono = valueOrEmpty('ltel');
        $mensaje = valueOrEmpty('message');

        $body = "";
        $body = $body."<strong>Info pasajero</strong><br/>";
        $body = $body."Email: ".$email."<br/>";
        $body = $body."Nombre: ".$fname." ".$lname."<br/>";
        $body = $body."Cantidad de pasajeros: ".$cantidad."<br/>";
        $body = $body."Telefono: ".$telefono."<br/>";
        $body = $body."Mensaje: ".$mensaje."<br/>";

        $subject = "Contacto Web - Argentina Incoming";
    }

    if(valueOrEmpty('hdnsource')=="creaexp"){
        $fname = valueOrEmpty('fname');
        $lname = valueOrEmpty('lname');
        $email = valueOrEmpty('email');
        $idioma = valueOrEmpty('lpais');
        $fcant = valueOrEmpty('fcant');
        $fedades = valueOrEmpty('fedades');
        $internacionales = valueOrEmpty('optradio');
        $fdesde = valueOrEmpty('fdesde');
        $fhasta = valueOrEmpty('fhasta');
        $fdias = valueOrEmpty('fdias');
        $flexradio = valueOrEmpty('flexradio');
        $destino = valueOrEmpty('destino');
        $otroDestino = valueOrEmpty('otroDestino');
        $experiencia = valueOrEmpty('experiencia');
        $otraExperiencia = valueOrEmpty('otraExperiencia');
        $servicio = valueOrEmpty('servicio');
        $otroServicio = valueOrEmpty('otroServicio');
        $categoria = valueOrEmpty('categoria');
        $mensaje = valueOrEmpty('message');
        $news = valueOrEmpty('news');
        if($news == ""){
          $news="No";
        }

        $body = "";
        $body = $body."<strong>Info pasajero</strong><br/>";
        $body = $body."Email: ".$email."<br/>";
        $body = $body."Nombre: ".$fname." ".$lname."<br/>";
        $body = $body."Mensaje: ".$mensaje."<br/>";
        $body = $body."<br/>";
        $body = $body."<strong>Info experiencia</strong><br/>";
        $body = $body."Cantidad de pasajeros: ".$fcant."<br/>";
        $body = $body."Edades: ".$fedades."<br/>";
        $body = $body."Vuelos internacionales: ".$internacionales."<br/>";
        $body = $body."Fecha desde: ".$fdesde."<br/>";
        $body = $body."Fecha hasta: ".$fhasta."<br/>";
        $body = $body."Cantidad de días: ".$fdias."<br/>";
        $body = $body."Fechas flexibles: ".$flexradio."<br/>";
        $body = $body."Idioma: ".$idioma."<br/>";
        $body = $body."Destino/s: ".$destino."<br/>";
        $body = $body."Otro destino: ".$otroDestino."<br/>";
        $body = $body."Experiencia/s: ".$experiencia."<br/>";
        $body = $body."Otra Experiencia: ".$otraExperiencia."<br/>";
        $body = $body."Servicio/s: ".$servicio."<br/>";
        $body = $body."Otro Servicio: ".$otroServicio."<br/>";
        $body = $body."Categoría hotel: ".$categoria."<br/>";
        $body = $body."<br/>";
        $body = $body."Suscripción newsletters: ".$news."<br/>";

        $subject = "Crea tu experiencia - Argentina Incoming";
    }

    #
    # RECAPTCHA SERVER SIDE VALIDATION
    #

    $recaptcha_secret = "6LcXqZEgAAAAAI_eGjFUQUnUh2FHCVYr_Tkt2Qwk";
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$recaptcha_secret."&response=".$_POST['g-recaptcha-response']);
    $response = json_decode($response, true);

    if($response["success"] === true){
      $sendEmailError = sendEmail($subject, $body);
    } else {
      $sendEmailError = true;
    }
  }

function sendEmail($subject, $body){
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->SMTPAuth = true;
    $mail->Username = "consultasweb@argentinaincoming.com.ar";
    $mail->Password = "bewsatlusnoc";
    $mail->setFrom("consultasweb@argentinaincoming.com.ar", "Consulta Web Argentina Incoming");
    $mail->addAddress("info@argentinaincoming.com.ar", "Info Argentina Incoming");
    $mail->Subject = $subject;
    $mail->msgHTML($body);

    $error = false;

    if(!$mail->send()){
        echo "Mailer Error: " . $mail->ErrorInfo;
        $error = true;
    }

    return $error;
  }

  function valueOrEmpty($name){
    if(isset($_POST)){
      $post = $_POST[$name];
      if(isset($post)) {
        if(is_array($post)){
          return implode("; ", $post);
        }
        return $post;
      }
    }
    return "";
  }

  function printOK(){
    echo <<<EOD
    <div class='col-12 mb-5 mensajeexito rounded'>
        <h3 class='font-weight-light text-center text-white'>
            El mensaje se ha enviado correctamente, te responderemos a la brevedad.
            <br/>
            ¡Muchas gracias!
        </h3>
    </div>
    EOD;
  }

  function printERROR(){
    echo <<<EOD
    <div class='col-12 mb-5 mensajeerror rounded'>
        <h3 class='font-weight-light text-center text-white'>
            Ha ocurrido un error enviando el mensaje. Por favor, reintente más tarde.
            <br/>
            ¡Muchas gracias!
        </h3>
    </div>
    EOD;
  }
?>
  <body>
  <div class="site-wrap">
    <?php include 'menu.html';?>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
            <?php
              if($_SERVER["REQUEST_METHOD"] == "POST" && !$sendEmailError) {
                printOK();
              }
              if($_SERVER["REQUEST_METHOD"] == "POST" && $sendEmailError) {
                printERROR();
              }
            ?>
          <div class="col-md-12 text-center">
            <p class="mb-0"><a href="index.php" class="btn btn-primary py-3 px-5 text-white rounded">Volver</a></p>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.html';?>
  </div>
  <?php include 'scripts.html';?>
  </body>
</html>