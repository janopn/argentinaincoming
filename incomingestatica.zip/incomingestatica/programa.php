<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   



  

   
    <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
			<h2 class="font-weight-light text-white mb-2" id="titulo">Cataratas del Iguazú</h2>
            <h5 class="font-weight-light text-white mb-1" id="noches">3 Noches</h5>
 
            <div class="mb-3">
              <img src="iconos/avion_b.svg" alt="Vuelo" width="36px" class="m-0 d-inline" />
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline" />
              <img src="iconos/hotel_b.svg" alt="Alojamiento" width="36px" class="m-0 d-inline" />
              <img src="iconos/excursion_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline" />
              <img src="iconos/asistencia_b.svg" alt="Asistencia" width="36px" class="m-0 d-inline" />
            </div>                
 
 
 
            <ul class="text-white pl-3">
              <li>Pasajes aéreos desde Buenos Aires</li>
              <li>Traslados de entrada y salida</li>
              <li>Alojamiento en el Hotel Cataratas Resort con régimen de desayuno</li>
              <li>Excursiones a las cataratas del lado argentino y brasilero</li>
              <li>Asistencia al viajero</li>
            </ul>  
 
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>

			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  
			  
			  
          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slideriguazu.jpg" alt="Image" class="img-fluid rounded" />
              <img src="images/sliderbariloche.jpg" alt="Image" class="img-fluid rounded" />
            </div>                                     
          
			  
          </div>
          
          
        </div>
      </div>
    </div>




    <div class="site-section">
      <div class="container">

        <form action="consultaprograma.php" class=" bg-light">

			
		  <div class="row bg-light">
			  			  	  			  
                <div class="col-12 col-md-9 mt-4 pl-3">
	    			<h3 class="font-weight-light azul">¡Reservá tu programa!</h3>
					<h6 class="mb-2" >Seleccioná la opción de tu preferencia y consultanos</h6>			
                </div>
                <!--
				<div class="col-12 col-md-3 mt-4  ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			    -->
   
		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  
          <!-- -->			  
		  <div class="row bg-light pb-3 mb-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha1">1/4/2022 al 31/7/2022</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel1">Amerian Resort & Spa</label>
	        </div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(1, 'DBL');" checked></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1DBL">u$d 590</strong>
	    		  <strong class="text-primary legal d-block" id="base1">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(1, 'FPL');"></input>   
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio1FPL">u$d 890</strong>
                  <strong class="text-primary legal d-block" id="base1">Por pasajero en FAMILY PLAN</strong> 
                </div>
              </div>    
			</div>		       
			
          </div>
		  <!-- -->
        
        
        
          <!-- -->			  
		  <div class="row bg-light pb-3 mb-5 mb-lg-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul invisible" id="rangofecha2">1/4/2022 al 31/7/2022</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel2">Sheraton Iguazú</label>
	        </div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(2, 'DBL');" ></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio2DBL">u$d 790</strong>
	    		  <strong class="text-primary legal d-block" id="base2">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(2, 'FPL');"></input>   
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio2FPL">u$d 1090</strong>
                  <strong class="text-primary legal d-block" id="base2">Por pasajero en FAMILY PLAN</strong> 
                </div>
              </div>    
			</div>		       
			
          </div>
		  <!-- -->
  
        
        
          <!-- -->			  
		  <div class="row bg-light pb-3  mb-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul" id="rangofecha3">1/8/2022 al 31/12/2022</label>		  
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel3">Amerian Resort & Spa</label>
	        </div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(3, 'DBL');" ></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio3DBL">u$d 650</strong>
	    		  <strong class="text-primary legal d-block" id="base3">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(3, 'FPL');"></input>   
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio3FPL">u$d 950</strong>
                  <strong class="text-primary legal d-block" id="base3">Por pasajero en FAMILY PLAN</strong> 
                </div>
              </div>    
			</div>		       
			
          </div>
		  <!-- -->
        
        
        
          <!-- -->			  
		  <div class="row bg-light pb-3 mb-5 mb-lg-0">
              
            <div class="col-lg-3 col-md-12  ">
               <label class="mb-3 h6 azul invisible" id="rangofecha4">1/8/2022 al 31/12/2022</label>		 
		    </div>	  
			  
   		    <div class="col-lg-3 col-md-12  ">			  
              <label class="mb-1 h6" id="hotel4">Sheraton Iguazú</label>
	        </div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(4, 'DBL');" ></input>
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio4DBL">u$d 850</strong>
	    		  <strong class="text-primary legal d-block" id="base4">Por pasajero en BASE DOBLE</strong> 	
                </div>
              </div>    
			</div>		

		    <div class="col-lg-3 col-md-12  ">	
              <div class="row">
                <div class="col-2">  
                  <input class="mr-1" type="radio" name="radio_paquetes" id="radio" onclick="lastRadioButton(4, 'FPL');"></input>   
                </div>
                <div class="col-10">
                  <strong class="text-primary precio d-block mb-1" id="precio4FPL">u$d 1150</strong>
                  <strong class="text-primary legal d-block" id="base4">Por pasajero en FAMILY PLAN</strong> 
                </div>
              </div>    
			</div>		       
			
          </div>
		  <!-- -->
        
        
        
        
		  <div class="row bg-light">		  
            <div class="col-12 mt-2 mb3">
				<strong class="text-primary legal d-block mb-3">Tarifas válidas hasta el 14/4/2022</strong>								
            </div>
		  </div>	
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
          <div class="row form-group pb-3 bg-light">
            <div class="col-md-12">
              <input type="submit" value="Continuar" class="btn btn-primary py-2 px-4 text-white rounded">
            </div>
          </div>
        
		  
          
        </form>
          
          
      </div>
    </div>    
	

	<!--	
	

    <div class="site-section">
      <div class="container">

        <form action="mejorahotel.php">

			
		  <div class="row bg-light">
			  			  
            <div class="col-lg-3 border-right mt-4 pt-4 pl-4">
			
              <!--<strong class="text-primary legal d-block">DESDE</strong>
              <strong class="text-primary preciodestacado d-block mb-1">u$d 590</strong>
              <strong class="text-primary legal d-block ">Tarifa final por pasajero en hotel/es de categoría 3 estrellas</strong>
			
			</div>
			  
			  
            <div class="col-lg-9 ">
			
    		  <div class="row bg-light ">
			  			  
                <div class="col-md-12 mt-4 ml-2">
	    			<h3 class="font-weight-light azul">¡Reservá tu programa!</h3>
					<h6 class="mb-2" >En 4 simples pasos y sin tarjeta de crédito</h6>			
                </div>
    		  </div>	  			 
			  
			
    		  <div class="row bg-light ">			  
                <div class="col-12 col-lg-9 mt-3 px-4">
    	  	      <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">Paso 1 de 4</div>
                  </div>				
    			</div>

				<div class="col-12 col-lg-3 mt-1 px-4 ">  
                    <input type="submit" value="Continuar" class="btn btn-primary text-white rounded ancho" />
    			</div> 		 
			  
    		  </div>	
			</div>

		  </div>	
			
			
			
			
			
		  
		  <div class="row bg-light">		  
            <div class="col-12 mt-2">
				<hr />								
            </div>
		  </div>	
			
			  
			  
		  <div class="row bg-light pb-3">		  			  
          <div class="col-lg-3 col-md-12 pad border-right">
                                                
            <label class="mb-1 h6 azul"  for="fechad">Fecha de inicio de viaje</label>
            <input type="text" name="fechad" class="form-control datepicker px-2 mb-4" placeholder="Desde" />

			  			  			  
			  
		  </div>	  
			  

		  <div class="col-lg-4 col-md-12 pad border-right">
			  
			  
            <label class="mb-1 h6 azul" for="categoria">Categoría de alojamiento</label>
            <select name="categoria" class="form-control mb-3">
              <option value="3est">3 estrellas</option>
              <option value="4est">4 estrellas</option>
              <option value="5est">5 estrellas</option>
            </select>
			  
               
            <label class="mb-1 h6" for="">Hoteles previstos:</label>
            <p class="">
              - Cataratas Resort & Spa<br/>
              - Puerto Iguazu Beach<br/>
            </p>

			  
	      </div>		

          <div class="col-lg-5 col-md-12 pad">


            <h6 class="mb-3 azul mt-1" >Habitaciones</h6>             
			  
            <div class="mb-0">
              <div>
                <label class="text-black m-0" >- Habitación 1</label>
              </div>  
			  <div class="row mb-0">	
                <div class="col-6 mb-0">
                  <label class="text-black m-0" for="adultos1">Adultos: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="adultos1" name="adultos1" min="1" max="4" value="2" />
    			</div>	  
                <div class="col-6 mb-0">				  
				  <label class="text-black m-0" for="menores1">Menores: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="menores1" name="menores1" min="0" max="2" value="0" />
				  <p class="legal m-0 ">(2 a 11 años inclusive)</p>  
    		    </div>
			  </div>
            </div>
			  
			<hr />  

			  
            <div class="mb-0">
              <div>
                <label class="text-black m-0" >- Habitación 2</label>
                <button type="button" class=" btn btn-papeler bg-transparent p-0" />
                <span class=" icon-trash-o"></span>  				  
              </div>  
			  <div class="row mb-0">	
                <div class="col-6 mb-0">
                  <label class="text-black m-0" for="adultos2">Adultos: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="adultos2" name="adultos2" min="1" max="4" value="2" />
    			</div>	  
                <div class="col-6 mb-0">				  
				  <label class="text-black m-0" for="menores2">Menores: </label>
                  <input class="form-control-pas ancho40 m-0" type="number" id="menores2" name="menores2" min="0" max="2" value="0" />
				  <p class="legal m-0 ">(2 a 11 años inclusive)</p>  
    		    </div>
			  </div>
            </div>
			  
	        <hr />
				
			  
            <div class="mb-4">
              <label class="text-black" for="infante1">Viajo con bebé/s: </label>
              <input type="checkbox"  id="infante1" class="d-inline " />
            </div>
				
				
				
			  			   
            <button type="button" class=" btn btn-primary py-1 px-2 mt-0 text-white d-block alto30 rounded " >
              <h6 class="line-height-1">Agregar habitación</h6>
            </button>  

				


          </div>
                   
          
          
          
 
          </div>
          
        </form>
          
          
      </div>
    </div>    
	
	  
	  
	-->  
	  
	  
		
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
 
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 1</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio <a href="experiencia.php" class=" d-inline subrayado">City Tour Panorámico</a> illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur <a href="experiencia.php" class="d-inline subrayado">Paseo en bici</a> adipisicing elit.</p>
                                
              </div>                
            </div>
            
            <hr />
               
            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 2</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus <a href="experiencia.php" class=" d-inline subrayado">Visita a bodega Zucardi</a> alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>
            
            <hr />

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 3</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>

              </div>                
            </div>

            
            <hr />

            <div class="row">
              <div class="col-12 col-md-2">
                <h5 class="mb-2">Dia 4</h5>
              </div>               
              <div class="col-12 col-md-10">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae cumque eius modi expedita accusamus alias error totam ab magnam a mollitia magni, distinctio temporibus optio illo sapiente, odio unde natus. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              </div>                
            </div>


          </div>
          
          
          
        </div>
      </div>
    </div>    
		
		
		
		
		
		
		
		
		
		
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios"  />
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>
  <?php include 'scriptsprogramas.html';?>

 

    
  </body>
</html>