<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   




   

    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
			
			
          <div class="col-12 mb-5 mensajeexito rounded iconomensaje">
            <span class="icon-check-circle iconomensaje"></span>      
            <h3 class="font-weight-light text-center text-white">El mensaje se ha enviado correctamente, te responderemos a la brevedad.<br/> ¡Muchas  gracias!</h3>          
          </div>
                      
          <div class="col-12 mb-5 mensajeerror rounded">
            <span class="icon-error iconomensaje"></span>      
            <h3 class="font-weight-light text-center text-white">Ha ocurrido un error enviando el mensaje. Por favor, reintente más tarde.<br/> ¡Muchas  gracias!</h3>          
          </div>
            
            
          <div class="col-md-12 text-center">
            <p class="mb-0"><a href="index.php" class="btn btn-primary py-3 px-5 text-white rounded">Volver</a></p>
          </div>
            
            
            
        </div>
      </div>
    </div>

    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>