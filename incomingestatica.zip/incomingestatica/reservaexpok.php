<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   

  
	  
	  
	  <div class="site-section bg-dark" >
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12">
            <h2 class="font-weight-light text-white mb-2">City Tour Panorámico</h2>
            <h5 class="font-weight-light text-white mb-1">Breve párrafo introductorio a la actividad o subtítulo</h2>
  
  
            <div class="mb-3">
              <img src="iconos/bus_b.svg" alt="Traslado" width="36px" class="m-0 d-inline">
              <img src="iconos/barco_b.svg" alt="Navegacion" width="36px" class="m-0 d-inline">
              <img src="iconos/bici_b.svg" alt="Excursiones" width="36px" class="m-0 d-inline">
              <img src="iconos/comida_b.svg" alt="Comida" width="36px" class="m-0 d-inline">
            </div>                
  
  
 
            <ul class="text-white pl-3 mb-4">
              <li>Bus turistico</li>
              <li>4 descensos</li>
              <li>Almuerzo (sin bebidas)</li>
            </ul>  
 
            
            <p class="font-weight-light text-white mb-0"><strong>Días disponibles:</strong> Lunes a Domingos</p>            
            <p class="font-weight-light text-white mb-0"><strong>Duración:</strong> 8 hs.</p>            
            <strong class="text-white d-inline mb-4">Idiomas disponibles:</strong>
            <span class="flag-icon flag-icon-es ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-gb ml-1 mb-4"></span>
            <span class="flag-icon flag-icon-pt ml-1 mb-4"></span>
 
			<div class="mb-3">  
             <a href="#seccionitinerario" class="text-white">Ver itinerario completo</a>
			</div>  			  



          </div>
          
          <div class="col-lg-6 col-md-12 ">
          
            <div class="slide-one-item home-slider owl-carousel">
              <img src="images/slidercaminito.jpg" alt="Image" class="img-fluid rounded">
              <img src="images/slidermapa.jpg" alt="Image" class="img-fluid rounded">
            </div>                                     
            
          </div>
          
          
        </div>
      </div>
    </div>
	  
	  
	  
	  
    <div class="site-section">
      <div class="container">
		  <div class="row bg-light">			  			  			  
            <div class="col py-5">	
	    	  <h3 class="font-weight-light azul d-inline">¡Tu reserva ha sido realizada con éxito! Nos comunicaremos con vos a la brevedad</h3>
			</div>
		  </div>	
		</div>	
    </div>    
	  
	  
	  
	  
	  
	  
    <div class="site-section" id="seccionitinerario">
      <div class="container">
        <div class="row">
		
		
          <div class="col-md-12 mb-4">
            <h3 class="font-weight-light mb-4">Itinerario</h3>
 
            <p>Comenzarás el tour visitando la zona norte de la ciudad, se destacan los barrios Retiro, Recoleta y Palermo, donde descubrirás por qué Buenos Aires es considerada la París de Sudamérica. Luego el centro histórico, cívico y financiero, ubicado en los barrios San Nicolás y Montserrat, con su emblemático Obelisco y la Plaza de Mayo.
No puede faltar la visita a los sectores que dieron origen a esta ciudad, San Telmo y La Boca, cuna de dos grandes pasiones locales: tango y fútbol. Finalizando el tour visitarás Puerto Madero, uno de los sitios más jóvenes de la ciudad y área gastronómica por excelencia. 
            </p>
            
          </div>
         
        </div>
      </div>
    </div>    
	  
	  
	  
	  
	  
	  
	  
	<div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>