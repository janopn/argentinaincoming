<!DOCTYPE html>
<html lang="en">

  <?php include 'head.html';?>

  <body>
  
  <div class="site-wrap">

    <?php include 'menu.html';?>   





 
    <div class="site-section bg-light ">
      
      <div class="container">


        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">TOURS</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/iguazu2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Cataratas del Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 590</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/bariloche2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Bariloche</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 790</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="programa.php" class="unit-2  rounded text-center">
              <img src="images/iguazu2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroprograma">
                <h4 class=" mb-1">Cataratas del Iguazú</h4>
                <h6 class=" mb-0 text-black">3 Noches</h6>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/avion_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/bus_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/hotel_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/excursion_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">
                  <img src="iconos/asistencia_n.svg" alt="Asistencia" height="26px" class="m-0 d-inline">
                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 590</strong>
              </div>
            </a>
          </div>

        </div>
      
      </div>
      
      <div class="container">  
        
        
        <div class="row justify-content-center mb-5 mt-4">
          <div class="col-md-7 text-center">
            <h2 class="font-weight-light text-black">EXPERIENCIAS</h2>
          </div>
        </div>

        <div class="row">


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/mujer2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">City Tour Buenos Aires</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 290</strong>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4 ">
            <a href="experiencia.php" class="unit-2  rounded text-center">
              <img src="images/caminito2.jpg" alt="Image" class="img-fluid ">
              <div class=" cuadroexperiencia">
                <h4 class=" mb-1">Calle Caminito</h4>
                <div class="mt-0 mb-0 text-left">
                  <img src="iconos/bus_n.svg" alt="Vuelo" height="26px" class="m-0 d-inline">
                  <img src="iconos/barco_n.svg" alt="Traslado" height="26px" class="m-0 d-inline">
                  <img src="iconos/bici_n.svg" alt="Alojamiento" height="26px" class="m-0 d-inline">
                  <img src="iconos/comida_n.svg" alt="Excursiones" height="26px" class="m-0 d-inline">

                </div>
              </div> 
              <hr class="m-0">
              <div class=" cuadrotarifa"> 
                  <strong class=" d-block desde m-0">desde</strong>
                  <strong class=" m-0 d-block precio">u$d 190</strong>
              </div>
            </a>
          </div>



        </div>
        
        
        
        
        
        
      </div>
    
    </div>

    <!-- <div class="site-section bg-light">
      
    </div> -->

<!--
    <div class="site-blocks-cover overlay inner-page-cover" style="background-image: url(images/hero_bg_2.jpg); background-attachment: fixed;">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-7" data-aos="fade-up" data-aos-delay="400">
            <a href="https://vimeo.com/channels/staffpicks/93951774" class="play-single-big mb-4 d-inline-block popup-vimeo"><span class="icon-play"></span></a>
            <h2 class="text-white font-weight-light mb-5 h1">Experience Our Outstanding Services</h2>
            
          </div>
        </div>
      </div>
    </div>  -->


    
    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <h2 class="mb-5 font-weight-light text-black">¿QUERÉS VIAJAR CON NOSOTROS?</h2>
            <p class="mb-0"><a href="contacto.php" class="btn btn-primary py-3 px-5 text-white">¡Consultanos!</a></p>
          </div>
        </div>
      </div>
    </div>    <div class="site-section border-top">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-2">
          </div>
          <div class="col-lg-8 col text-center">
            <img class="responsive medio" src="images/mediosdepago.jpg" alt="Medios">
          </div>
         </div>
      </div>
    </div>
    
    
    
    <?php include 'footer.html';?>
    

  </div>


  <?php include 'scripts.html';?>

 

    
  </body>
</html>