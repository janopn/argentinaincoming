function validateField(name){
    var value = document.forms["Form"][name].value;

    document.getElementById(name).style.borderColor = null;

    if (value==null || value=="") {
      document.getElementById(name).style.borderColor = "red";
      return false;
    }

    return true;
}